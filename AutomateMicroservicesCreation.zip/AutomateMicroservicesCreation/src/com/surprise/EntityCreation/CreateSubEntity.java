package com.surprise.EntityCreation;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;

public class CreateSubEntity {
	private String PATH;
	private String EntityName;
	private String mainEntityName;
	public String getMainEntityName() {
		return mainEntityName;
	}

	public void setMainEntityName(String mainEntityName) {
		this.mainEntityName = mainEntityName;
	}

	public String getEntityName() {
		return EntityName;
	}

	public void setEntityName(String entityName) {
		EntityName = entityName;
	}
	private HashMap<String, String> props;
	private HashMap<String, String> mainEntityprops;
	
	

	public CreateSubEntity(String pATH, HashMap<String, String> props, String mainEntityName, HashMap<String, String> mainEntityprops) {
		PATH = pATH;
		this.props = props;
		this.mainEntityName = mainEntityName;
		this.mainEntityprops = mainEntityprops;
	}

	public HashMap<String, String> getProps() {
		return props;
	}

	public void setProps(HashMap<String, String> props) {
		this.props = props;
	}

	public String getPATH() {
		return PATH;
	}

	public void setPATH(String PATH) {
		this.PATH = PATH;
	}

	public void createMainDirectory()
	{
		String path = PATH;
		String[] arr = path.split("/");
		if(arr.length>1)
		{
			String[] strarr = new String[arr.length];
			for(int i=0; i<arr.length; i++)
			{
				if(i==0)
					strarr[i] = arr[i];
				else
					strarr[i] = strarr[i-1] + "/" + arr[i];
				//System.out.println(PATH+"/"+strarr[i]);
				File directory = new File(strarr[i]);
				if(!directory.exists())
				{
					directory.mkdir();
				}
			}
		}
		else
		{
			File directory = new File(PATH+"/"+path);
			if(!directory.exists())
			{
				directory.mkdir();
			}
		}
	}
	
	public void createPom() throws IOException {
		// TODO Auto-generated method stub
		String data = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n"
				+ "<project xmlns=\"http://maven.apache.org/POM/4.0.0\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"\r\n"
				+ "	xsi:schemaLocation=\"http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd\">\r\n"
				+ "	<modelVersion>4.0.0</modelVersion>\r\n"
				+ "	<parent>\r\n"
				+ "		<groupId>org.springframework.boot</groupId>\r\n"
				+ "		<artifactId>spring-boot-starter-parent</artifactId>\r\n"
				+ "		<version>2.7.2</version>\r\n"
				+ "		<relativePath/> <!-- lookup parent from repository -->\r\n"
				+ "	</parent>\r\n"
				+ "	<groupId>com.nayan</groupId>\r\n"
				+ "	<artifactId>"+EntityName+"</artifactId>\r\n"
				+ "	<version>0.0.1-SNAPSHOT</version>\r\n"
				+ "	<name>"+EntityName+"</name>\r\n"
				+ "	<description>User For Microservice</description>\r\n"
				+ "	<properties>\r\n"
				+ "		<java.version>17</java.version>\r\n"
				+ "		<spring-cloud.version>2021.0.3</spring-cloud.version>\r\n"
				+ "	</properties>\r\n"
				+ "	<dependencies>\r\n"
				+ "		<dependency>\r\n"
				+ "			<groupId>org.springframework.boot</groupId>\r\n"
				+ "			<artifactId>spring-boot-starter-data-jpa</artifactId>\r\n"
				+ "		</dependency>\r\n"
				+ "		<dependency>\r\n"
				+ "			<groupId>org.springframework.boot</groupId>\r\n"
				+ "			<artifactId>spring-boot-starter-web</artifactId>\r\n"
				+ "		</dependency>\r\n"
				+ "		<!-- https://mvnrepository.com/artifact/org.projectlombok/lombok -->\r\n"
				+ "		<dependency>\r\n"
				+ "		    <groupId>org.projectlombok</groupId>\r\n"
				+ "		    <artifactId>lombok</artifactId>\r\n"
				+ "		    <scope>provided</scope>\r\n"
				+ "		</dependency>\r\n"
				+ "\r\n"
				+ "\r\n"
				+ "		<dependency>\r\n"
				+ "	      <groupId>org.springframework.cloud</groupId>\r\n"
				+ "	      <artifactId>spring-cloud-starter-netflix-eureka-client</artifactId>\r\n"
				+ "	    </dependency>\r\n"
				+ "		<dependency>\r\n"
				+ "			<groupId>org.springframework.boot</groupId>\r\n"
				+ "			<artifactId>spring-boot-devtools</artifactId>\r\n"
				+ "			<scope>runtime</scope>\r\n"
				+ "			<optional>true</optional>\r\n"
				+ "		</dependency>\r\n"
				+ "		<dependency>\r\n"
				+ "			<groupId>mysql</groupId>\r\n"
				+ "			<artifactId>mysql-connector-java</artifactId>\r\n"
				+ "			<scope>runtime</scope>\r\n"
				+ "		</dependency>\r\n"
				+ "		<dependency>\r\n"
				+ "			<groupId>org.springframework.boot</groupId>\r\n"
				+ "			<artifactId>spring-boot-starter-test</artifactId>\r\n"
				+ "			<scope>test</scope>\r\n"
				+ "		</dependency>\r\n"
				+ "		<dependency>\r\n"
				+ "			<groupId>io.github.resilience4j</groupId>\r\n"
				+ "			<artifactId>resilience4j-spring-boot2</artifactId>\r\n"
				+ "			\r\n"
				+ "		</dependency>"
				+ "	</dependencies>\r\n"
				+ "\r\n"
				+ "	<dependencyManagement>\r\n"
				+ "	    <dependencies>\r\n"
				+ "	      <dependency>\r\n"
				+ "	        <groupId>org.springframework.cloud</groupId>\r\n"
				+ "	        <artifactId>spring-cloud-dependencies</artifactId>\r\n"
				+ "	        <version>${spring-cloud.version}</version>\r\n"
				+ "	        <type>pom</type>\r\n"
				+ "	        <scope>import</scope>\r\n"
				+ "	      </dependency>\r\n"
				+ "	    </dependencies>\r\n"
				+ "	  </dependencyManagement>\r\n"
				+ "\r\n"
				+ "	<build>\r\n"
				+ "		<plugins>\r\n"
				+ "			<plugin>\r\n"
				+ "				<groupId>org.springframework.boot</groupId>\r\n"
				+ "				<artifactId>spring-boot-maven-plugin</artifactId>\r\n"
				+ "			</plugin>\r\n"
				+ "		</plugins>\r\n"
				+ "	</build>\r\n"
				+ "\r\n"
				+ "</project>";
		FileWriter fileWriter = new FileWriter(PATH+"/pom.xml");
		fileWriter.write(data);
		fileWriter.close();
	}
	
	public void createmvnwFile() throws IOException
	{
		String data = "#!/bin/sh\r\n"
				+ "# ----------------------------------------------------------------------------\r\n"
				+ "# Licensed to the Apache Software Foundation (ASF) under one\r\n"
				+ "# or more contributor license agreements.  See the NOTICE file\r\n"
				+ "# distributed with this work for additional information\r\n"
				+ "# regarding copyright ownership.  The ASF licenses this file\r\n"
				+ "# to you under the Apache License, Version 2.0 (the\r\n"
				+ "# \"License\"); you may not use this file except in compliance\r\n"
				+ "# with the License.  You may obtain a copy of the License at\r\n"
				+ "#\r\n"
				+ "#    https://www.apache.org/licenses/LICENSE-2.0\r\n"
				+ "#\r\n"
				+ "# Unless required by applicable law or agreed to in writing,\r\n"
				+ "# software distributed under the License is distributed on an\r\n"
				+ "# \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY\r\n"
				+ "# KIND, either express or implied.  See the License for the\r\n"
				+ "# specific language governing permissions and limitations\r\n"
				+ "# under the License.\r\n"
				+ "# ----------------------------------------------------------------------------\r\n"
				+ "\r\n"
				+ "# ----------------------------------------------------------------------------\r\n"
				+ "# Maven Start Up Batch script\r\n"
				+ "#\r\n"
				+ "# Required ENV vars:\r\n"
				+ "# ------------------\r\n"
				+ "#   JAVA_HOME - location of a JDK home dir\r\n"
				+ "#\r\n"
				+ "# Optional ENV vars\r\n"
				+ "# -----------------\r\n"
				+ "#   M2_HOME - location of maven2's installed home dir\r\n"
				+ "#   MAVEN_OPTS - parameters passed to the Java VM when running Maven\r\n"
				+ "#     e.g. to debug Maven itself, use\r\n"
				+ "#       set MAVEN_OPTS=-Xdebug -Xrunjdwp:transport=dt_socket,server=y,suspend=y,address=8000\r\n"
				+ "#   MAVEN_SKIP_RC - flag to disable loading of mavenrc files\r\n"
				+ "# ----------------------------------------------------------------------------\r\n"
				+ "\r\n"
				+ "if [ -z \"$MAVEN_SKIP_RC\" ] ; then\r\n"
				+ "\r\n"
				+ "  if [ -f /usr/local/etc/mavenrc ] ; then\r\n"
				+ "    . /usr/local/etc/mavenrc\r\n"
				+ "  fi\r\n"
				+ "\r\n"
				+ "  if [ -f /etc/mavenrc ] ; then\r\n"
				+ "    . /etc/mavenrc\r\n"
				+ "  fi\r\n"
				+ "\r\n"
				+ "  if [ -f \"$HOME/.mavenrc\" ] ; then\r\n"
				+ "    . \"$HOME/.mavenrc\"\r\n"
				+ "  fi\r\n"
				+ "\r\n"
				+ "fi\r\n"
				+ "\r\n"
				+ "# OS specific support.  $var _must_ be set to either true or false.\r\n"
				+ "cygwin=false;\r\n"
				+ "darwin=false;\r\n"
				+ "mingw=false\r\n"
				+ "case \"`uname`\" in\r\n"
				+ "  CYGWIN*) cygwin=true ;;\r\n"
				+ "  MINGW*) mingw=true;;\r\n"
				+ "  Darwin*) darwin=true\r\n"
				+ "    # Use /usr/libexec/java_home if available, otherwise fall back to /Library/Java/Home\r\n"
				+ "    # See https://developer.apple.com/library/mac/qa/qa1170/_index.html\r\n"
				+ "    if [ -z \"$JAVA_HOME\" ]; then\r\n"
				+ "      if [ -x \"/usr/libexec/java_home\" ]; then\r\n"
				+ "        export JAVA_HOME=\"`/usr/libexec/java_home`\"\r\n"
				+ "      else\r\n"
				+ "        export JAVA_HOME=\"/Library/Java/Home\"\r\n"
				+ "      fi\r\n"
				+ "    fi\r\n"
				+ "    ;;\r\n"
				+ "esac\r\n"
				+ "\r\n"
				+ "if [ -z \"$JAVA_HOME\" ] ; then\r\n"
				+ "  if [ -r /etc/gentoo-release ] ; then\r\n"
				+ "    JAVA_HOME=`java-config --jre-home`\r\n"
				+ "  fi\r\n"
				+ "fi\r\n"
				+ "\r\n"
				+ "if [ -z \"$M2_HOME\" ] ; then\r\n"
				+ "  ## resolve links - $0 may be a link to maven's home\r\n"
				+ "  PRG=\"$0\"\r\n"
				+ "\r\n"
				+ "  # need this for relative symlinks\r\n"
				+ "  while [ -h \"$PRG\" ] ; do\r\n"
				+ "    ls=`ls -ld \"$PRG\"`\r\n"
				+ "    link=`expr \"$ls\" : '.*-> \\(.*\\)$'`\r\n"
				+ "    if expr \"$link\" : '/.*' > /dev/null; then\r\n"
				+ "      PRG=\"$link\"\r\n"
				+ "    else\r\n"
				+ "      PRG=\"`dirname \"$PRG\"`/$link\"\r\n"
				+ "    fi\r\n"
				+ "  done\r\n"
				+ "\r\n"
				+ "  saveddir=`pwd`\r\n"
				+ "\r\n"
				+ "  M2_HOME=`dirname \"$PRG\"`/..\r\n"
				+ "\r\n"
				+ "  # make it fully qualified\r\n"
				+ "  M2_HOME=`cd \"$M2_HOME\" && pwd`\r\n"
				+ "\r\n"
				+ "  cd \"$saveddir\"\r\n"
				+ "  # echo Using m2 at $M2_HOME\r\n"
				+ "fi\r\n"
				+ "\r\n"
				+ "# For Cygwin, ensure paths are in UNIX format before anything is touched\r\n"
				+ "if $cygwin ; then\r\n"
				+ "  [ -n \"$M2_HOME\" ] &&\r\n"
				+ "    M2_HOME=`cygpath --unix \"$M2_HOME\"`\r\n"
				+ "  [ -n \"$JAVA_HOME\" ] &&\r\n"
				+ "    JAVA_HOME=`cygpath --unix \"$JAVA_HOME\"`\r\n"
				+ "  [ -n \"$CLASSPATH\" ] &&\r\n"
				+ "    CLASSPATH=`cygpath --path --unix \"$CLASSPATH\"`\r\n"
				+ "fi\r\n"
				+ "\r\n"
				+ "# For Mingw, ensure paths are in UNIX format before anything is touched\r\n"
				+ "if $mingw ; then\r\n"
				+ "  [ -n \"$M2_HOME\" ] &&\r\n"
				+ "    M2_HOME=\"`(cd \"$M2_HOME\"; pwd)`\"\r\n"
				+ "  [ -n \"$JAVA_HOME\" ] &&\r\n"
				+ "    JAVA_HOME=\"`(cd \"$JAVA_HOME\"; pwd)`\"\r\n"
				+ "fi\r\n"
				+ "\r\n"
				+ "if [ -z \"$JAVA_HOME\" ]; then\r\n"
				+ "  javaExecutable=\"`which javac`\"\r\n"
				+ "  if [ -n \"$javaExecutable\" ] && ! [ \"`expr \\\"$javaExecutable\\\" : '\\([^ ]*\\)'`\" = \"no\" ]; then\r\n"
				+ "    # readlink(1) is not available as standard on Solaris 10.\r\n"
				+ "    readLink=`which readlink`\r\n"
				+ "    if [ ! `expr \"$readLink\" : '\\([^ ]*\\)'` = \"no\" ]; then\r\n"
				+ "      if $darwin ; then\r\n"
				+ "        javaHome=\"`dirname \\\"$javaExecutable\\\"`\"\r\n"
				+ "        javaExecutable=\"`cd \\\"$javaHome\\\" && pwd -P`/javac\"\r\n"
				+ "      else\r\n"
				+ "        javaExecutable=\"`readlink -f \\\"$javaExecutable\\\"`\"\r\n"
				+ "      fi\r\n"
				+ "      javaHome=\"`dirname \\\"$javaExecutable\\\"`\"\r\n"
				+ "      javaHome=`expr \"$javaHome\" : '\\(.*\\)/bin'`\r\n"
				+ "      JAVA_HOME=\"$javaHome\"\r\n"
				+ "      export JAVA_HOME\r\n"
				+ "    fi\r\n"
				+ "  fi\r\n"
				+ "fi\r\n"
				+ "\r\n"
				+ "if [ -z \"$JAVACMD\" ] ; then\r\n"
				+ "  if [ -n \"$JAVA_HOME\"  ] ; then\r\n"
				+ "    if [ -x \"$JAVA_HOME/jre/sh/java\" ] ; then\r\n"
				+ "      # IBM's JDK on AIX uses strange locations for the executables\r\n"
				+ "      JAVACMD=\"$JAVA_HOME/jre/sh/java\"\r\n"
				+ "    else\r\n"
				+ "      JAVACMD=\"$JAVA_HOME/bin/java\"\r\n"
				+ "    fi\r\n"
				+ "  else\r\n"
				+ "    JAVACMD=\"`\\\\unset -f command; \\\\command -v java`\"\r\n"
				+ "  fi\r\n"
				+ "fi\r\n"
				+ "\r\n"
				+ "if [ ! -x \"$JAVACMD\" ] ; then\r\n"
				+ "  echo \"Error: JAVA_HOME is not defined correctly.\" >&2\r\n"
				+ "  echo \"  We cannot execute $JAVACMD\" >&2\r\n"
				+ "  exit 1\r\n"
				+ "fi\r\n"
				+ "\r\n"
				+ "if [ -z \"$JAVA_HOME\" ] ; then\r\n"
				+ "  echo \"Warning: JAVA_HOME environment variable is not set.\"\r\n"
				+ "fi\r\n"
				+ "\r\n"
				+ "CLASSWORLDS_LAUNCHER=org.codehaus.plexus.classworlds.launcher.Launcher\r\n"
				+ "\r\n"
				+ "# traverses directory structure from process work directory to filesystem root\r\n"
				+ "# first directory with .mvn subdirectory is considered project base directory\r\n"
				+ "find_maven_basedir() {\r\n"
				+ "\r\n"
				+ "  if [ -z \"$1\" ]\r\n"
				+ "  then\r\n"
				+ "    echo \"Path not specified to find_maven_basedir\"\r\n"
				+ "    return 1\r\n"
				+ "  fi\r\n"
				+ "\r\n"
				+ "  basedir=\"$1\"\r\n"
				+ "  wdir=\"$1\"\r\n"
				+ "  while [ \"$wdir\" != '/' ] ; do\r\n"
				+ "    if [ -d \"$wdir\"/.mvn ] ; then\r\n"
				+ "      basedir=$wdir\r\n"
				+ "      break\r\n"
				+ "    fi\r\n"
				+ "    # workaround for JBEAP-8937 (on Solaris 10/Sparc)\r\n"
				+ "    if [ -d \"${wdir}\" ]; then\r\n"
				+ "      wdir=`cd \"$wdir/..\"; pwd`\r\n"
				+ "    fi\r\n"
				+ "    # end of workaround\r\n"
				+ "  done\r\n"
				+ "  echo \"${basedir}\"\r\n"
				+ "}\r\n"
				+ "\r\n"
				+ "# concatenates all lines of a file\r\n"
				+ "concat_lines() {\r\n"
				+ "  if [ -f \"$1\" ]; then\r\n"
				+ "    echo \"$(tr -s '\\n' ' ' < \"$1\")\"\r\n"
				+ "  fi\r\n"
				+ "}\r\n"
				+ "\r\n"
				+ "BASE_DIR=`find_maven_basedir \"$(pwd)\"`\r\n"
				+ "if [ -z \"$BASE_DIR\" ]; then\r\n"
				+ "  exit 1;\r\n"
				+ "fi\r\n"
				+ "\r\n"
				+ "##########################################################################################\r\n"
				+ "# Extension to allow automatically downloading the maven-wrapper.jar from Maven-central\r\n"
				+ "# This allows using the maven wrapper in projects that prohibit checking in binary data.\r\n"
				+ "##########################################################################################\r\n"
				+ "if [ -r \"$BASE_DIR/.mvn/wrapper/maven-wrapper.jar\" ]; then\r\n"
				+ "    if [ \"$MVNW_VERBOSE\" = true ]; then\r\n"
				+ "      echo \"Found .mvn/wrapper/maven-wrapper.jar\"\r\n"
				+ "    fi\r\n"
				+ "else\r\n"
				+ "    if [ \"$MVNW_VERBOSE\" = true ]; then\r\n"
				+ "      echo \"Couldn't find .mvn/wrapper/maven-wrapper.jar, downloading it ...\"\r\n"
				+ "    fi\r\n"
				+ "    if [ -n \"$MVNW_REPOURL\" ]; then\r\n"
				+ "      jarUrl=\"$MVNW_REPOURL/org/apache/maven/wrapper/maven-wrapper/3.1.0/maven-wrapper-3.1.0.jar\"\r\n"
				+ "    else\r\n"
				+ "      jarUrl=\"https://repo.maven.apache.org/maven2/org/apache/maven/wrapper/maven-wrapper/3.1.0/maven-wrapper-3.1.0.jar\"\r\n"
				+ "    fi\r\n"
				+ "    while IFS=\"=\" read key value; do\r\n"
				+ "      case \"$key\" in (wrapperUrl) jarUrl=\"$value\"; break ;;\r\n"
				+ "      esac\r\n"
				+ "    done < \"$BASE_DIR/.mvn/wrapper/maven-wrapper.properties\"\r\n"
				+ "    if [ \"$MVNW_VERBOSE\" = true ]; then\r\n"
				+ "      echo \"Downloading from: $jarUrl\"\r\n"
				+ "    fi\r\n"
				+ "    wrapperJarPath=\"$BASE_DIR/.mvn/wrapper/maven-wrapper.jar\"\r\n"
				+ "    if $cygwin; then\r\n"
				+ "      wrapperJarPath=`cygpath --path --windows \"$wrapperJarPath\"`\r\n"
				+ "    fi\r\n"
				+ "\r\n"
				+ "    if command -v wget > /dev/null; then\r\n"
				+ "        if [ \"$MVNW_VERBOSE\" = true ]; then\r\n"
				+ "          echo \"Found wget ... using wget\"\r\n"
				+ "        fi\r\n"
				+ "        if [ -z \"$MVNW_USERNAME\" ] || [ -z \"$MVNW_PASSWORD\" ]; then\r\n"
				+ "            wget \"$jarUrl\" -O \"$wrapperJarPath\" || rm -f \"$wrapperJarPath\"\r\n"
				+ "        else\r\n"
				+ "            wget --http-user=$MVNW_USERNAME --http-password=$MVNW_PASSWORD \"$jarUrl\" -O \"$wrapperJarPath\" || rm -f \"$wrapperJarPath\"\r\n"
				+ "        fi\r\n"
				+ "    elif command -v curl > /dev/null; then\r\n"
				+ "        if [ \"$MVNW_VERBOSE\" = true ]; then\r\n"
				+ "          echo \"Found curl ... using curl\"\r\n"
				+ "        fi\r\n"
				+ "        if [ -z \"$MVNW_USERNAME\" ] || [ -z \"$MVNW_PASSWORD\" ]; then\r\n"
				+ "            curl -o \"$wrapperJarPath\" \"$jarUrl\" -f\r\n"
				+ "        else\r\n"
				+ "            curl --user $MVNW_USERNAME:$MVNW_PASSWORD -o \"$wrapperJarPath\" \"$jarUrl\" -f\r\n"
				+ "        fi\r\n"
				+ "\r\n"
				+ "    else\r\n"
				+ "        if [ \"$MVNW_VERBOSE\" = true ]; then\r\n"
				+ "          echo \"Falling back to using Java to download\"\r\n"
				+ "        fi\r\n"
				+ "        javaClass=\"$BASE_DIR/.mvn/wrapper/MavenWrapperDownloader.java\"\r\n"
				+ "        # For Cygwin, switch paths to Windows format before running javac\r\n"
				+ "        if $cygwin; then\r\n"
				+ "          javaClass=`cygpath --path --windows \"$javaClass\"`\r\n"
				+ "        fi\r\n"
				+ "        if [ -e \"$javaClass\" ]; then\r\n"
				+ "            if [ ! -e \"$BASE_DIR/.mvn/wrapper/MavenWrapperDownloader.class\" ]; then\r\n"
				+ "                if [ \"$MVNW_VERBOSE\" = true ]; then\r\n"
				+ "                  echo \" - Compiling MavenWrapperDownloader.java ...\"\r\n"
				+ "                fi\r\n"
				+ "                # Compiling the Java class\r\n"
				+ "                (\"$JAVA_HOME/bin/javac\" \"$javaClass\")\r\n"
				+ "            fi\r\n"
				+ "            if [ -e \"$BASE_DIR/.mvn/wrapper/MavenWrapperDownloader.class\" ]; then\r\n"
				+ "                # Running the downloader\r\n"
				+ "                if [ \"$MVNW_VERBOSE\" = true ]; then\r\n"
				+ "                  echo \" - Running MavenWrapperDownloader.java ...\"\r\n"
				+ "                fi\r\n"
				+ "                (\"$JAVA_HOME/bin/java\" -cp .mvn/wrapper MavenWrapperDownloader \"$MAVEN_PROJECTBASEDIR\")\r\n"
				+ "            fi\r\n"
				+ "        fi\r\n"
				+ "    fi\r\n"
				+ "fi\r\n"
				+ "##########################################################################################\r\n"
				+ "# End of extension\r\n"
				+ "##########################################################################################\r\n"
				+ "\r\n"
				+ "export MAVEN_PROJECTBASEDIR=${MAVEN_BASEDIR:-\"$BASE_DIR\"}\r\n"
				+ "if [ \"$MVNW_VERBOSE\" = true ]; then\r\n"
				+ "  echo $MAVEN_PROJECTBASEDIR\r\n"
				+ "fi\r\n"
				+ "MAVEN_OPTS=\"$(concat_lines \"$MAVEN_PROJECTBASEDIR/.mvn/jvm.config\") $MAVEN_OPTS\"\r\n"
				+ "\r\n"
				+ "# For Cygwin, switch paths to Windows format before running java\r\n"
				+ "if $cygwin; then\r\n"
				+ "  [ -n \"$M2_HOME\" ] &&\r\n"
				+ "    M2_HOME=`cygpath --path --windows \"$M2_HOME\"`\r\n"
				+ "  [ -n \"$JAVA_HOME\" ] &&\r\n"
				+ "    JAVA_HOME=`cygpath --path --windows \"$JAVA_HOME\"`\r\n"
				+ "  [ -n \"$CLASSPATH\" ] &&\r\n"
				+ "    CLASSPATH=`cygpath --path --windows \"$CLASSPATH\"`\r\n"
				+ "  [ -n \"$MAVEN_PROJECTBASEDIR\" ] &&\r\n"
				+ "    MAVEN_PROJECTBASEDIR=`cygpath --path --windows \"$MAVEN_PROJECTBASEDIR\"`\r\n"
				+ "fi\r\n"
				+ "\r\n"
				+ "# Provide a \"standardized\" way to retrieve the CLI args that will\r\n"
				+ "# work with both Windows and non-Windows executions.\r\n"
				+ "MAVEN_CMD_LINE_ARGS=\"$MAVEN_CONFIG $@\"\r\n"
				+ "export MAVEN_CMD_LINE_ARGS\r\n"
				+ "\r\n"
				+ "WRAPPER_LAUNCHER=org.apache.maven.wrapper.MavenWrapperMain\r\n"
				+ "\r\n"
				+ "exec \"$JAVACMD\" \\\r\n"
				+ "  $MAVEN_OPTS \\\r\n"
				+ "  $MAVEN_DEBUG_OPTS \\\r\n"
				+ "  -classpath \"$MAVEN_PROJECTBASEDIR/.mvn/wrapper/maven-wrapper.jar\" \\\r\n"
				+ "  \"-Dmaven.home=${M2_HOME}\" \\\r\n"
				+ "  \"-Dmaven.multiModuleProjectDirectory=${MAVEN_PROJECTBASEDIR}\" \\\r\n"
				+ "  ${WRAPPER_LAUNCHER} $MAVEN_CONFIG \"$@\"";
		FileWriter fileWriter = new FileWriter(PATH+"/mvnw");
		fileWriter.write(data);
		fileWriter.close();
	}
	public void createHelpMdFile() throws IOException
	{
		String data = "# Getting Started\r\n"
				+ "\r\n"
				+ "### Reference Documentation\r\n"
				+ "For further reference, please consider the following sections:\r\n"
				+ "\r\n"
				+ "* [Official Apache Maven documentation](https://maven.apache.org/guides/index.html)\r\n"
				+ "* [Spring Boot Maven Plugin Reference Guide](https://docs.spring.io/spring-boot/docs/2.7.2/maven-plugin/reference/html/)\r\n"
				+ "* [Create an OCI image](https://docs.spring.io/spring-boot/docs/2.7.2/maven-plugin/reference/html/#build-image)\r\n"
				+ "* [Spring Boot DevTools](https://docs.spring.io/spring-boot/docs/2.7.2/reference/htmlsingle/#using.devtools)\r\n"
				+ "* [Spring Data JPA](https://docs.spring.io/spring-boot/docs/2.7.2/reference/htmlsingle/#data.sql.jpa-and-spring-data)\r\n"
				+ "* [Spring Web](https://docs.spring.io/spring-boot/docs/2.7.2/reference/htmlsingle/#web)\r\n"
				+ "\r\n"
				+ "### Guides\r\n"
				+ "The following guides illustrate how to use some features concretely:\r\n"
				+ "\r\n"
				+ "* [Accessing data with MySQL](https://spring.io/guides/gs/accessing-data-mysql/)\r\n"
				+ "* [Accessing Data with JPA](https://spring.io/guides/gs/accessing-data-jpa/)\r\n"
				+ "* [Building a RESTful Web Service](https://spring.io/guides/gs/rest-service/)\r\n"
				+ "* [Serving Web Content with Spring MVC](https://spring.io/guides/gs/serving-web-content/)\r\n"
				+ "* [Building REST services with Spring](https://spring.io/guides/tutorials/rest/)";
		FileWriter fileWriter = new FileWriter(PATH+"/HELP.md");
		fileWriter.write(data);
		fileWriter.close();
	}
	public void createProjectFile() throws IOException
	{
		String data = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n"
				+ "<projectDescription>\r\n"
				+ "	<name>"+EntityName+"</name>\r\n"
				+ "	<comment></comment>\r\n"
				+ "	<projects>\r\n"
				+ "	</projects>\r\n"
				+ "	<buildSpec>\r\n"
				+ "		<buildCommand>\r\n"
				+ "			<name>org.eclipse.jdt.core.javabuilder</name>\r\n"
				+ "			<arguments>\r\n"
				+ "			</arguments>\r\n"
				+ "		</buildCommand>\r\n"
				+ "		<buildCommand>\r\n"
				+ "			<name>org.eclipse.m2e.core.maven2Builder</name>\r\n"
				+ "			<arguments>\r\n"
				+ "			</arguments>\r\n"
				+ "		</buildCommand>\r\n"
				+ "		<buildCommand>\r\n"
				+ "			<name>org.springframework.ide.eclipse.boot.validation.springbootbuilder</name>\r\n"
				+ "			<arguments>\r\n"
				+ "			</arguments>\r\n"
				+ "		</buildCommand>\r\n"
				+ "	</buildSpec>\r\n"
				+ "	<natures>\r\n"
				+ "		<nature>org.eclipse.jdt.core.javanature</nature>\r\n"
				+ "		<nature>org.eclipse.m2e.core.maven2Nature</nature>\r\n"
				+ "	</natures>\r\n"
				+ "</projectDescription>";
		FileWriter fileWriter = new FileWriter(PATH+"/.project");
		fileWriter.write(data);
		fileWriter.close();
	}
	public void createGitIgnoreFile() throws IOException
	{
		String data = "HELP.md\r\n"
				+ "target/\r\n"
				+ "!.mvn/wrapper/maven-wrapper.jar\r\n"
				+ "!**/src/main/**/target/\r\n"
				+ "!**/src/test/**/target/\r\n"
				+ "\r\n"
				+ "### STS ###\r\n"
				+ ".apt_generated\r\n"
				+ ".classpath\r\n"
				+ ".factorypath\r\n"
				+ ".project\r\n"
				+ ".settings\r\n"
				+ ".springBeans\r\n"
				+ ".sts4-cache\r\n"
				+ "\r\n"
				+ "### IntelliJ IDEA ###\r\n"
				+ ".idea\r\n"
				+ "*.iws\r\n"
				+ "*.iml\r\n"
				+ "*.ipr\r\n"
				+ "\r\n"
				+ "### NetBeans ###\r\n"
				+ "/nbproject/private/\r\n"
				+ "/nbbuild/\r\n"
				+ "/dist/\r\n"
				+ "/nbdist/\r\n"
				+ "/.nb-gradle/\r\n"
				+ "build/\r\n"
				+ "!**/src/main/**/build/\r\n"
				+ "!**/src/test/**/build/\r\n"
				+ "\r\n"
				+ "### VS Code ###\r\n"
				+ ".vscode/";
		FileWriter fileWriter = new FileWriter(PATH+"/.gitignore");
		fileWriter.write(data);
		fileWriter.close();
	}
	public void createClassPathFile() throws IOException
	{
		String data = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n"
				+ "<classpath>\r\n"
				+ "	<classpathentry kind=\"src\" output=\"target/classes\" path=\"src/main/java\">\r\n"
				+ "		<attributes>\r\n"
				+ "			<attribute name=\"optional\" value=\"true\"/>\r\n"
				+ "			<attribute name=\"maven.pomderived\" value=\"true\"/>\r\n"
				+ "		</attributes>\r\n"
				+ "	</classpathentry>\r\n"
				+ "	<classpathentry excluding=\"**\" kind=\"src\" output=\"target/classes\" path=\"src/main/resources\">\r\n"
				+ "		<attributes>\r\n"
				+ "			<attribute name=\"maven.pomderived\" value=\"true\"/>\r\n"
				+ "		</attributes>\r\n"
				+ "	</classpathentry>\r\n"
				+ "	<classpathentry kind=\"src\" output=\"target/test-classes\" path=\"src/test/java\">\r\n"
				+ "		<attributes>\r\n"
				+ "			<attribute name=\"test\" value=\"true\"/>\r\n"
				+ "			<attribute name=\"optional\" value=\"true\"/>\r\n"
				+ "			<attribute name=\"maven.pomderived\" value=\"true\"/>\r\n"
				+ "		</attributes>\r\n"
				+ "	</classpathentry>\r\n"
				+ "	<classpathentry kind=\"con\" path=\"org.eclipse.jdt.launching.JRE_CONTAINER/org.eclipse.jdt.internal.debug.ui.launcher.StandardVMType/JavaSE-17\">\r\n"
				+ "		<attributes>\r\n"
				+ "			<attribute name=\"module\" value=\"true\"/>\r\n"
				+ "			<attribute name=\"maven.pomderived\" value=\"true\"/>\r\n"
				+ "		</attributes>\r\n"
				+ "	</classpathentry>\r\n"
				+ "	<classpathentry kind=\"con\" path=\"org.eclipse.m2e.MAVEN2_CLASSPATH_CONTAINER\">\r\n"
				+ "		<attributes>\r\n"
				+ "			<attribute name=\"maven.pomderived\" value=\"true\"/>\r\n"
				+ "		</attributes>\r\n"
				+ "	</classpathentry>\r\n"
				+ "	<classpathentry kind=\"output\" path=\"target/classes\"/>\r\n"
				+ "</classpath>";
		FileWriter fileWriter = new FileWriter(PATH+"/.classpath");
		fileWriter.write(data);
		fileWriter.close();
	}
	private void createDirectory(String path)
	{
		String[] arr = path.split("/");
		if(arr.length>1)
		{
			String[] strarr = new String[arr.length];
			for(int i=0; i<arr.length; i++)
			{
				if(i==0)
					strarr[i] = arr[i];
				else
					strarr[i] = strarr[i-1] + "/" + arr[i];
				//System.out.println(PATH+"/"+strarr[i]);
				File directory = new File(PATH+"/"+strarr[i]);
				if(!directory.exists())
				{
					directory.mkdir();
				}
			}
		}
		else
		{
			File directory = new File(PATH+"/"+path);
			if(!directory.exists())
			{
				directory.mkdir();
			}
		}
	}
	public void createEntityAppClass() throws IOException
	{
		String str = EntityName;
		String path = "src/main/java/com/example/demo";
		createDirectory(path);
		String data = "package com.example.demo;\r\n"
				+ "\r\n"
				+ "import org.springframework.boot.SpringApplication;\r\n"
				+ "import org.springframework.boot.autoconfigure.SpringBootApplication;\r\n"
				+ "import org.springframework.cloud.client.loadbalancer.LoadBalanced;\r\n"
				+ "import org.springframework.cloud.netflix.eureka.EnableEurekaClient;\r\n"
				+ "import org.springframework.context.annotation.Bean;\r\n"
				+ "import org.springframework.web.client.RestTemplate;\r\n"
				+ "\r\n"
				+ "@SpringBootApplication\r\n"
				+ "@EnableEurekaClient\r\n"
				+ "public class "+str+"Application {\r\n"
				+ "\r\n"
				+ "	public static void main(String[] args) {\r\n"
				+ "		SpringApplication.run("+str+"Application.class, args);\r\n"
				+ "	}\r\n"
				+ " @Bean\r\n"
				+ "	@LoadBalanced\r\n"
				+ "	RestTemplate restTemplate()\r\n"
				+ "	{\r\n"
				+ "		return new RestTemplate();\r\n"
				+ "	}"
				+ "\r\n"
				+ "}";
		FileWriter fileWriter = new FileWriter(PATH+"/"+path+"/"+str+"Application.java");
		fileWriter.write(data);
		fileWriter.close();
	}
	private String getEntityWithGettersAndSetters()
	{
		String res = "";
		for(String name: props.keySet())
		{
			if(name.toLowerCase().equals("id"))
			{
				res += "@Id\r\n"
				+ "	@GeneratedValue(strategy = GenerationType.IDENTITY)\r\n"
				+ "	private int id;\r\n"
				+ "\r\n";
			}
			else
			{
				res += "private "+props.get(name)+" "+name+";\r\n"
						+ "	\r\n"
						+ "\r\n";
			}
		}
		return res;
	}
	private String getMainEntityWithGettersAndSetters()
	{
		String res = "";
		for(String name: mainEntityprops.keySet())
		{
			if(name.toLowerCase().equals("id"))
			{
				res += "@Id\r\n"
				+ "	@GeneratedValue(strategy = GenerationType.IDENTITY)\r\n"
				+ "	private int id;\r\n"
				+ "\r\n";
			}
			else
			{
				res += "private "+ mainEntityprops.get(name)+" "+name+";\r\n"
						+ "	\r\n"
						+ "\r\n";
			}
		}
		return res;
	}
	public void createMainEntityClass() throws IOException
	{
		String str = mainEntityName;
		String path = "src/main/java/com/example/demo/vo";
		createDirectory(path);
		String data = "package com.example.demo.vo;\r\n"
				+ "\r\n"
				+ "import javax.persistence.Entity;\r\n"
				+ "import javax.persistence.GeneratedValue;\r\n"
				+ "import javax.persistence.GenerationType;\r\n"
				+ "import javax.persistence.Id;\r\n"
				+ "import javax.persistence.Table;\r\n"
				+ "import lombok.AllArgsConstructor;\r\n"
				+ "import lombok.Data;\r\n"
				+ "import lombok.EqualsAndHashCode;\r\n"
				+ "import lombok.NoArgsConstructor;\r\n"
				+ "import lombok.ToString;"
				+ "\r\n"
				+ "@Entity\r\n"
				+ "@Table(name=\""+str+"\")\r\n"
				+ "@Data\r\n"
				+ "@AllArgsConstructor\r\n"
				+ "@NoArgsConstructor\r\n"
				+ "\r\n"
				+ "public class "+(str.substring(0, 1).toUpperCase()+str.substring(1))+" {\r\n"
				+ "\r\n"
				+ getMainEntityWithGettersAndSetters()
				+ "	\r\n"
				+ "	\r\n"
				+ "}";
		FileWriter fileWriter = new FileWriter(PATH+"/"+path+"/"+(str.substring(0, 1).toUpperCase()+str.substring(1))+".java");
		fileWriter.write(data);
		fileWriter.close();
	}
	public void createEntityVOClass() throws IOException
	{
		String str = EntityName;
		String main = mainEntityName;
		String path = "src/main/java/com/example/demo/vo";
		createDirectory(path);
		String data = "package com.example.demo.vo;\r\n"
				+ "\r\n"
				+ "import javax.persistence.GeneratedValue;\r\n"
				+ "import javax.persistence.GenerationType;\r\n"
				+ "import lombok.AllArgsConstructor;\r\n"
				+ "import lombok.Data;\r\n"
				+ "import lombok.EqualsAndHashCode;\r\n"
				+ "import lombok.NoArgsConstructor;\r\n"
				+ "import lombok.ToString;\r\n"
				+ ""
				+ "import com.example.demo.entity."+(str.substring(0, 1).toUpperCase()+str.substring(1))+";\r\n"
				+ "\r\n"
				+ "import java.util.List;\r\n"
				+ "@Data\r\n"
				+ "@AllArgsConstructor\r\n"
				+ "@NoArgsConstructor\r\n"
				+ "\r\n"
				+ "public class "+(str.substring(0, 1).toUpperCase()+str.substring(1))+"VO {\r\n"
				+ "\r\n"
				+ "private "+(str.substring(0, 1).toUpperCase()+str.substring(1))+" "+str.toLowerCase()+";\r\n"
				+ "	private List<"+(main.substring(0, 1).toUpperCase()+main.substring(1))+"> "+main.toLowerCase()+";"
				+ "	\r\n"
				+ "	\r\n"
				+ "}";
		FileWriter fileWriter = new FileWriter(PATH+"/"+path+"/"+(str.substring(0, 1).toUpperCase()+str.substring(1))+"VO.java");
		fileWriter.write(data);
		fileWriter.close();
	}
	public void createEntityEntityClass() throws IOException
	{
		String str = EntityName;
		String path = "src/main/java/com/example/demo/entity";
		createDirectory(path);
		String data = "package com.example.demo.entity;\r\n"
				+ "\r\n"
				+ "import javax.persistence.Entity;\r\n"
				+ "import javax.persistence.GeneratedValue;\r\n"
				+ "import javax.persistence.GenerationType;\r\n"
				+ "import javax.persistence.Id;\r\n"
				+ "import javax.persistence.Table;\r\n"
				+ "import lombok.AllArgsConstructor;\r\n"
				+ "import lombok.Data;\r\n"
				+ "import lombok.EqualsAndHashCode;\r\n"
				+ "import lombok.NoArgsConstructor;\r\n"
				+ "import lombok.ToString;"
				+ "\r\n"
				+ "@Entity\r\n"
				+ "@Table(name=\""+str+"\")\r\n"
				+ "@Data\r\n"
				+ "@AllArgsConstructor\r\n"
				+ "@NoArgsConstructor\r\n"
				+ "\r\n"
				+ "public class "+(str.substring(0, 1).toUpperCase()+str.substring(1))+" {\r\n"
				+ "\r\n"
				+ getEntityWithGettersAndSetters()
				+ "	\r\n"
				+ "	\r\n"
				+ "}";
		FileWriter fileWriter = new FileWriter(PATH+"/"+path+"/"+(str.substring(0, 1).toUpperCase()+str.substring(1))+".java");
		fileWriter.write(data);
		fileWriter.close();
	}
	public void createEntityRepository() throws IOException
	{
		String str = EntityName;
		String path = "src/main/java/com/example/demo/repository";
		createDirectory(path);
		String data = "package com.example.demo.repository;\r\n"
				+ "\r\n"
				+ "import org.springframework.data.jpa.repository.JpaRepository;\r\n"
				+ "import org.springframework.stereotype.Repository;\r\n"
				+ "\r\n"
				+ "import com.example.demo.entity."+(str.substring(0, 1).toUpperCase()+str.substring(1))+";\r\n"
				+ "\r\n"
				+ "@Repository\r\n"
				+ "public interface "+(str.substring(0, 1).toUpperCase()+str.substring(1))+"Repository extends JpaRepository<"+(str.substring(0, 1).toUpperCase()+str.substring(1))+", Integer> {\r\n"
				+ "\r\n"
				+ "}";
		FileWriter fileWriter = new FileWriter(PATH+"/"+path+"/"+(str.substring(0, 1).toUpperCase()+str.substring(1))+"Repository.java");
		fileWriter.write(data);
		fileWriter.close();
	}
	public void createEntityImplementation() throws IOException
	{
		String str = EntityName;
		String main = mainEntityName;
		String path = "src/main/java/com/example/demo/implementation";
		createDirectory(path);
		String data = "package com.example.demo.implementation;\r\n"
				+ "\r\n"
				+ "import java.util.List;\r\n"
				+ "\r\n"
				+ "import com.example.demo.controller.AddResponse;\r\n"
				+ "import com.example.demo.entity."+(str.substring(0, 1).toUpperCase()+str.substring(1))+";\r\n"
				+ "\r\n"
				+ "import com.example.demo.vo."+(str.substring(0, 1).toUpperCase()+str.substring(1))+"VO;\r\n"
				+ "\r\n"
				+ "public interface "+(str.substring(0, 1).toUpperCase()+str.substring(1))+"Impl {\r\n"
				+ "	\r\n"
				+ "	public List<"+(str.substring(0, 1).toUpperCase()+str.substring(1))+"> getAll"+(str.substring(0, 1).toUpperCase()+str.substring(1))+"s();\r\n"
				+ "	\r\n"
				+ "	public "+(str.substring(0, 1).toUpperCase()+str.substring(1))+" get"+(str.substring(0, 1).toUpperCase()+str.substring(1))+"ById(int id);\r\n"
				+ "	\r\n"
				+ "	public "+(str.substring(0, 1).toUpperCase()+str.substring(1))+" add"+(str.substring(0, 1).toUpperCase()+str.substring(1))+"("+(str.substring(0, 1).toUpperCase()+str.substring(1))+ " "+(str.substring(0, 1).toLowerCase()+str.substring(1))+");\r\n"
				+ "	\r\n"
				+ "public List<"+(str.substring(0, 1).toUpperCase()+str.substring(1))+"> addList(List<"+(str.substring(0, 1).toUpperCase()+str.substring(1))+"> "+str.toLowerCase()+");"
				+ "\r\n"
				+ "	public "+(str.substring(0, 1).toUpperCase()+str.substring(1))+" update"+(str.substring(0, 1).toUpperCase()+str.substring(1))+"("+(str.substring(0, 1).toUpperCase()+str.substring(1))+ " "+(str.substring(0, 1).toUpperCase()+str.substring(1))+");\r\n"
				+ "	\r\n"
				+ " public List<"+(str.substring(0, 1).toUpperCase()+str.substring(1))+"VO> "+(main.substring(0, 1).toUpperCase()+main.substring(1))+"forParticular"+str.toLowerCase()+"(int id);"
				+ " \r\n"
				+ " public List<"+(str.substring(0, 1).toUpperCase()+str.substring(1))+"VO> "+(main.substring(0, 1).toUpperCase()+main.substring(1))+"forParticularResil"+str.toLowerCase()+"(int id);"
				+ " \r\n"
				+ "	public AddResponse delete"+(str.substring(0, 1).toUpperCase()+str.substring(1))+"(int id);\r\n"
				+ "}\r\n"
				+ "";
		FileWriter fileWriter = new FileWriter(PATH+"/"+path+"/"+(str.substring(0, 1).toUpperCase()+str.substring(1))+"Impl.java");
		fileWriter.write(data);
		fileWriter.close();
	}
	public void createEntityService() throws IOException
	{
		String str = EntityName;
		String main = mainEntityName;
		String path = "src/main/java/com/example/demo/service";
		createDirectory(path);
		String data = "package com.example.demo.service;\r\n"
				+ "\r\n"
				+ "import java.util.Arrays;\r\n"
				+ "import java.util.Collections;\r\n"
				+ "import java.util.List;\r\n"
				+ "import java.util.Optional;\r\n"
				+ "import java.util.stream.Collectors;\r\n"
				+ "\r\n"
				+ "import org.springframework.beans.factory.annotation.Autowired;\r\n"
				+ "import org.springframework.stereotype.Component;\r\n"
				+ "import org.springframework.stereotype.Service;\r\n"
				+ "import org.springframework.web.client.RestTemplate;\r\n"
				+ "\r\n"
				+ "import com.example.demo.controller.AddResponse;\r\n"
				+ "import com.example.demo.entity."+(str.substring(0, 1).toUpperCase()+str.substring(1))+";\r\n"
				+ "import com.example.demo.implementation."+(str.substring(0, 1).toUpperCase()+str.substring(1))+"Impl;\r\n"
				+ "import com.example.demo.repository."+(str.substring(0, 1).toUpperCase()+str.substring(1))+"Repository;\r\n"
				+ "import com.example.demo.vo."+(str.substring(0, 1).toUpperCase()+str.substring(1))+"VO;\r\n"
				+ "import com.example.demo.vo."+(main.substring(0, 1).toUpperCase()+main.substring(1))+";\r\n"		
				+ "\r\n"
				+ "\r\n"
				+ "@Service\r\n"
				+ "@Component\r\n"
				+ "public class "+(str.substring(0, 1).toUpperCase()+str.substring(1))+"Service implements "+(str.substring(0, 1).toUpperCase()+str.substring(1))+"Impl {\r\n"
				+ "\r\n"
				+ "	@Autowired\r\n"
				+ "	"+(str.substring(0, 1).toUpperCase()+str.substring(1))+"Repository "+str.toLowerCase()+"Repository;\r\n"
				+ "	\r\n"
				+ "	\r\n"
				+ "@Autowired\r\n"
				+ "	RestTemplate restTemp;"
				+ " \r\n"
				+ "	@Override\r\n"
				+ "	public List<"+(str.substring(0, 1).toUpperCase()+str.substring(1))+"> getAll"+(str.substring(0, 1).toUpperCase()+str.substring(1))+"s() {\r\n"
				+ "		// TODO Auto-generated method stub\r\n"
				+ "		return "+str.toLowerCase()+"Repository.findAll();\r\n"
				+ "	}\r\n"
				+ "\r\n"
				+ "	@Override\r\n"
				+ "	public "+(str.substring(0, 1).toUpperCase()+str.substring(1))+" get"+(str.substring(0, 1).toUpperCase()+str.substring(1))+"ById(int id) {\r\n"
				+ "		// TODO Auto-generated method stub\r\n"
				+ "		return "+str.toLowerCase()+"Repository.findById(id).get();\r\n"
				+ "	}\r\n"
				+ "\r\n"
				+ "	@Override\r\n"
				+ "	public "+(str.substring(0, 1).toUpperCase()+str.substring(1))+" add"+(str.substring(0, 1).toUpperCase()+str.substring(1))+"("+(str.substring(0, 1).toUpperCase()+str.substring(1))+" "+str.toLowerCase()+") {\r\n"
				+ "		// TODO Auto-generated method stub\r\n"
				+ "		int id = "+str.toLowerCase()+"Repository.findAll().size() + 1;\r\n"
				+ "		"+str.toLowerCase()+".setId(id);\r\n"
				+ "		"+str.toLowerCase()+"Repository.save("+str.toLowerCase()+");\r\n"
				+ "		return "+str.toLowerCase()+";\r\n"
				+ "	}\r\n"
				+ "@Override\r\n"
				+ "	public List<"+(str.substring(0, 1).toUpperCase()+str.substring(1))+"> addList(List<"+(str.substring(0, 1).toUpperCase()+str.substring(1))+"> "+str.toLowerCase()+") {\r\n"
				+ "		"+str.toLowerCase()+"Repository.saveAll("+str.toLowerCase()+");\r\n"
				+ "		return "+str.toLowerCase()+";\r\n"
				+ "	}"
				+ "\r\n"
				+ "	@Override\r\n"
				+ "	public "+(str.substring(0, 1).toUpperCase()+str.substring(1))+" update"+(str.substring(0, 1).toUpperCase()+str.substring(1))+"("+(str.substring(0, 1).toUpperCase()+str.substring(1))+" "+str.toLowerCase()+") {\r\n"
				+ "		// TODO Auto-generated method stub\r\n"
				+ "		"+str.toLowerCase()+"Repository.save("+str.toLowerCase()+");\r\n"
				+ "		return "+str.toLowerCase()+";\r\n"
				+ "	}\r\n"
				+ "\r\n"
				+ "	@Override\r\n"
				+ "	public List<"+(str.substring(0, 1).toUpperCase()+str.substring(1))+"VO> "+(main.substring(0, 1).toUpperCase()+main.substring(1))+"forParticular"+str.toLowerCase()+"(int id) {\r\n"
				+ "		// TODO Auto-generated method stub\r\n"
				+ " List<"+(str.substring(0, 1).toUpperCase()+str.substring(1))+"VO> fulllist = this.getAll"+(str.substring(0, 1).toUpperCase()+str.substring(1))+"s().stream().filter(p -> p.getId()==id).map(p -> {\r\n"
				+ "			"+(str.substring(0, 1).toUpperCase()+str.substring(1))+" colg = p; \r\n"
				+ "			List<"+(main.substring(0, 1).toUpperCase()+main.substring(1))+"> slist = Arrays.asList(\r\n"
				+ "					restTemp.getForEntity(\"http://"+main.toUpperCase()+"-SERVICE/"+main.toLowerCase()+"/"+str.toLowerCase()+"/\" + id, "+(main.substring(0, 1).toUpperCase()+main.substring(1))+"[].class).getBody());\r\n"
				+ "			return new "+(str.substring(0, 1).toUpperCase()+str.substring(1))+"VO(colg, slist);\r\n"
				+ "		}).collect(Collectors.toList());\r\n"
				+ "		return fulllist;"
				+ "	}\r\n"
				+ "\r\n"
				+ "	@Override\r\n"
				+ "	public List<"+(str.substring(0, 1).toUpperCase()+str.substring(1))+"VO> "+(main.substring(0, 1).toUpperCase()+main.substring(1))+"forParticularResil"+str.toLowerCase()+"(int id) {\r\n"
				+ "		// TODO Auto-generated method stub\r\n"
				+ " List<"+(str.substring(0, 1).toUpperCase()+str.substring(1))+"VO> fulllist = this.getAll"+(str.substring(0, 1).toUpperCase()+str.substring(1))+"s().stream().filter(p -> p.getId()==id).map(p -> {\r\n"
				+ "			"+(str.substring(0, 1).toUpperCase()+str.substring(1))+" colg = p; \r\n"
				+ "			List<"+(main.substring(0, 1).toUpperCase()+main.substring(1))+"> slist = null;\r\n"
				+ "			return new "+(str.substring(0, 1).toUpperCase()+str.substring(1))+"VO(colg, slist);\r\n"
				+ "		}).collect(Collectors.toList());\r\n"
				+ "		return fulllist;"
				+ "	}\r\n"
				+ "\r\n"
				+ "	@Override\r\n"
				+ "	public AddResponse delete"+(str.substring(0, 1).toUpperCase()+str.substring(1))+"(int id) {\r\n"
				+ "		// TODO Auto-generated method stub\r\n"
				+ "		"+str.toLowerCase()+"Repository.deleteById(id);\r\n"
				+ "		AddResponse res = new AddResponse();\r\n"
				+ "		res.setId(id);\r\n"
				+ "		res.setMsg(\""+(str.substring(0, 1).toUpperCase()+str.substring(1))+" Deleted...\");\r\n"
				+ "		return res;\r\n"
				+ "	}\r\n"
				+ "\r\n"
				+ "}";
		FileWriter fileWriter = new FileWriter(PATH+"/"+path+"/"+(str.substring(0, 1).toUpperCase()+str.substring(1))+"Service.java");
		fileWriter.write(data);
		fileWriter.close();
	}
	private String updateEntity()
	{
		String str = EntityName;
		String res = "		try {\r\n"
				+ "			"+(str.substring(0, 1).toUpperCase()+str.substring(1))+" old"+(str.substring(0, 1).toUpperCase()+str.substring(1, 3))+" = "+str.substring(0, 3).toLowerCase()+"Service.get"+(str.substring(0, 1).toUpperCase()+str.substring(1))+"ById(id);\r\n";
		
		for(String st: props.keySet())
		{
			res += "			old"+(str.substring(0, 1).toUpperCase()+str.substring(1, 3))+".set"+(st.substring(0, 1).toUpperCase()+st.substring(1))+"("+str.toLowerCase()+".get"+(st.substring(0, 1).toUpperCase()+st.substring(1))+"());\r\n";
		}
		
		res += "			"+str.toLowerCase()+" = "+str.substring(0, 3).toLowerCase()+"Service.update"+(str.substring(0, 1).toUpperCase()+str.substring(1))+"(old"+(str.substring(0, 1).toUpperCase()+str.substring(1, 3))+");\r\n"
				+ "			return new ResponseEntity<"+(str.substring(0, 1).toUpperCase()+str.substring(1))+">("+str.toLowerCase()+", HttpStatus.OK);\r\n";
		return res;
	}
	public void createEntityController() throws IOException
	{
		String str = EntityName;
		String main = mainEntityName;
		String path = "src/main/java/com/example/demo/controller";
		createDirectory(path);
		String data = "package com.example.demo.controller;\r\n"
				+ "\r\n"
				+ "import java.util.List;\r\n"
				+ "\r\n"
				+ "import org.springframework.beans.factory.annotation.Autowired;\r\n"
				+ "import org.springframework.http.HttpStatus;\r\n"
				+ "import org.springframework.http.ResponseEntity;\r\n"
				+ "import org.springframework.web.bind.annotation.CrossOrigin;\r\n"
				+ "import org.springframework.web.bind.annotation.DeleteMapping;\r\n"
				+ "import org.springframework.web.bind.annotation.GetMapping;\r\n"
				+ "import org.springframework.web.bind.annotation.PathVariable;\r\n"
				+ "import org.springframework.web.bind.annotation.PostMapping;\r\n"
				+ "import org.springframework.web.bind.annotation.PutMapping;\r\n"
				+ "import org.springframework.web.bind.annotation.RequestBody;\r\n"
				+ "import org.springframework.web.bind.annotation.RequestMapping;\r\n"
				+ "import org.springframework.web.bind.annotation.RestController;\r\n"
				+ "import com.example.demo.vo."+(str.substring(0, 1).toUpperCase()+str.substring(1))+"VO;\r\n"
				+ "\r\n"
				+ "import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;"
				+ "import com.example.demo.entity."+(str.substring(0, 1).toUpperCase()+str.substring(1))+";\r\n"
				+ "import com.example.demo.service."+(str.substring(0, 1).toUpperCase()+str.substring(1))+"Service;\r\n"
				+ "\r\n"
				+ "@CrossOrigin(origins=\"*\", allowedHeaders = \"*\")"
				+ "@RestController\r\n"
				+ "@RequestMapping(\"/"+str.toLowerCase()+"\")\r\n"
				+ "public class "+(str.substring(0, 1).toUpperCase()+str.substring(1))+"Controller {\r\n"
				+ "	\r\n"
				+ "	@Autowired\r\n"
				+ "	"+(str.substring(0, 1).toUpperCase()+str.substring(1))+"Service "+str.substring(0, 3).toLowerCase()+"Service;\r\n"
				+ "	\r\n"
				+ "private static final String RESILIENCEVALUE = \""+(str.substring(0, 1).toUpperCase() + str.substring(1).toLowerCase())+"\" ;"
				+ " \r\n"
				+ "	@GetMapping(\"/\")\r\n"
				+ "	public ResponseEntity<List<"+(str.substring(0, 1).toUpperCase()+str.substring(1))+">> getAll"+(str.substring(0, 1).toUpperCase()+str.substring(1))+"s()\r\n"
				+ "	{\r\n"
				+ "		List<"+(str.substring(0, 1).toUpperCase()+str.substring(1))+"> "+str.toLowerCase()+"s = "+str.substring(0, 3).toLowerCase()+"Service.getAll"+(str.substring(0, 1).toUpperCase()+str.substring(1))+"s();\r\n"
				+ "		return new ResponseEntity<List<"+(str.substring(0, 1).toUpperCase()+str.substring(1))+">>("+str.toLowerCase()+"s, HttpStatus.OK);\r\n"
				+ "	}\r\n"
				+ "	\r\n"
				+ "	@GetMapping(\"/{id}\")\r\n"
				+ "	public ResponseEntity<"+(str.substring(0, 1).toUpperCase()+str.substring(1))+"> get"+(str.substring(0, 1).toUpperCase()+str.substring(1))+"Byid(@PathVariable(value=\"id\") int id)\r\n"
				+ "	{\r\n"
				+ "		"+(str.substring(0, 1).toUpperCase()+str.substring(1))+" "+str.toLowerCase()+" = "+str.substring(0, 3).toLowerCase()+"Service.get"+(str.substring(0, 1).toUpperCase()+str.substring(1))+"ById(id);\r\n"
				+ "		return new ResponseEntity<"+(str.substring(0, 1).toUpperCase()+str.substring(1))+">("+str.toLowerCase()+", HttpStatus.OK);"
				+ "	}\r\n"
				+ "	\r\n"
				+ "	@PostMapping(\"/\")\r\n"
				+ "	public ResponseEntity<"+(str.substring(0, 1).toUpperCase()+str.substring(1))+"> add"+(str.substring(0, 1).toUpperCase()+str.substring(1))+"(@RequestBody "+(str.substring(0, 1).toUpperCase()+str.substring(1))+" "+str.toLowerCase()+")\r\n"
				+ "	{\r\n"
				+ "		return new ResponseEntity<"+(str.substring(0, 1).toUpperCase()+str.substring(1))+">("+str.substring(0, 3).toLowerCase()+"Service.add"+(str.substring(0, 1).toUpperCase()+str.substring(1))+"("+str.toLowerCase()+")"+", HttpStatus.OK);\r\n"
				+ "	}\r\n"
				+ "	\r\n"
				+ "@PostMapping(\"/\")\r\n"
				+ "	public ResponseEntity<List<"+(str.substring(0, 1).toUpperCase()+str.substring(1))+">> addBulk(@RequestBody List<"+(str.substring(0, 1).toUpperCase()+str.substring(1))+"> "+str.toLowerCase()+"){\r\n"
				+ "		try {\r\n"
				+ "			 List<"+(str.substring(0, 1).toUpperCase()+str.substring(1))+"> "+str.substring(0, 3).toLowerCase()+"="+str.substring(0, 3).toLowerCase()+"Service.addList("+str.toLowerCase()+");\r\n"
				+ "			 return new ResponseEntity<List<"+(str.substring(0, 1).toUpperCase()+str.substring(1))+">>("+str.substring(0, 3).toLowerCase()+",HttpStatus.CREATED);\r\n"
				+ "		}catch(Exception e) {\r\n"
				+ "			return new ResponseEntity<>(HttpStatus.CONFLICT);\r\n"
				+ "		}\r\n"
				+ "	}"
				+ "	@PutMapping(\"/{id}\")\r\n"
				+ "	public ResponseEntity<"+(str.substring(0, 1).toUpperCase()+str.substring(1))+"> update"+(str.substring(0, 1).toUpperCase()+str.substring(1))+"(@PathVariable(value=\"id\") int id, @RequestBody "+(str.substring(0, 1).toUpperCase()+str.substring(1))+" "+str.toLowerCase()+")\r\n"
				+ "	{\r\n"
				+ updateEntity()
				+ "		} catch (Exception e) {\r\n"
				+ "			// TODO Auto-generated catch block\r\n"
				+ "			return new ResponseEntity<"+(str.substring(0, 1).toUpperCase()+str.substring(1))+">(HttpStatus.CONFLICT);\r\n"
				+ "		}\r\n"
				+ "	}\r\n"
				+ "	\r\n"
				+ "	@GetMapping(\"/"+str.toLowerCase()+"-"+main.toLowerCase()+"/{id}\")\r\n"
				+ " @CircuitBreaker(name=RESILIENCEVALUE, fallbackMethod = \"getResilvalues\")\r\n"
				+ "	public ResponseEntity<?> "+(main.substring(0, 1).toUpperCase()+main.substring(1))+"List(@PathVariable(value=\"id\") int id){\r\n"
				+ "		List<"+(str.substring(0, 1).toUpperCase()+str.substring(1))+"VO> col = "+str.substring(0, 3).toLowerCase()+"Service."+(main.substring(0, 1).toUpperCase()+main.substring(1))+"forParticular"+str.toLowerCase()+"(id);\r\n"
				+ "		 return new ResponseEntity<List<"+(str.substring(0, 1).toUpperCase()+str.substring(1))+"VO>>(col,HttpStatus.FOUND);\r\n"
				+ "	}\r\n"
				+ "	public ResponseEntity<?> getResilvalues(@PathVariable(value=\"id\") int id){\r\n"
				+ "		List<"+(str.substring(0, 1).toUpperCase()+str.substring(1))+"VO> col = "+str.substring(0, 3).toLowerCase()+"Service."+(main.substring(0, 1).toUpperCase()+main.substring(1))+"forParticularResil"+str.toLowerCase()+"(id);\r\n"
				+ "		 return new ResponseEntity<List<"+(str.substring(0, 1).toUpperCase()+str.substring(1))+"VO>>(col,HttpStatus.FOUND);\r\n"
				+ "	}\r\n"
				+ "	@GetMapping(\"/delete"+str.toLowerCase()+"/{id}\")\r\n"
				+ "	public void delete"+(str.substring(0, 1).toUpperCase()+str.substring(1))+"s(@PathVariable(value=\"id\") int id)\r\n"
				+ "	{\r\n"
				+ "	}\r\n"
				+ "	@DeleteMapping(\"/delete"+str.toLowerCase()+"/{id}\")\r\n"
				+ "	public AddResponse delete"+(str.substring(0, 1).toUpperCase()+str.substring(1))+"(@PathVariable(value=\"id\") int id)\r\n"
				+ "	{\r\n"
				+ "		AddResponse res = "+str.substring(0, 3).toLowerCase()+"Service.delete"+(str.substring(0, 1).toUpperCase()+str.substring(1))+"(id);\r\n"
				+ "		return res;\r\n"
				+ "	}\r\n"
				+ "}";
		FileWriter fileWriter = new FileWriter(PATH+"/"+path+"/"+(str.substring(0, 1).toUpperCase()+str.substring(1))+"Controller.java");
		fileWriter.write(data);
		fileWriter.close();
	}
	public void createAddResponse() throws IOException
	{
		String path = "src/main/java/com/example/demo/controller";
		createDirectory(path);
		String data = "package com.example.demo.controller;\r\n"
				+ "\r\n"
				+ "public class AddResponse {\r\n"
				+ "	\r\n"
				+ "	private String msg;\r\n"
				+ "	private int id;\r\n"
				+ "	public AddResponse(int i, String string) {\r\n"
				+ "		// TODO Auto-generated constructor stub\r\n"
				+ "	}\r\n"
				+ "	\r\n"
				+ "	\r\n"
				+ "	public AddResponse() {\r\n"
				+ "	}\r\n"
				+ "\r\n"
				+ "\r\n"
				+ "	public String getMsg() {\r\n"
				+ "		return msg;\r\n"
				+ "	}\r\n"
				+ "	public void setMsg(String msg) {\r\n"
				+ "		this.msg = msg;\r\n"
				+ "	}\r\n"
				+ "	public int getId() {\r\n"
				+ "		return id;\r\n"
				+ "	}\r\n"
				+ "	public void setId(int id) {\r\n"
				+ "		this.id = id;\r\n"
				+ "	}\r\n"
				+ "}";
		FileWriter fileWriter = new FileWriter(PATH+"/"+path+"/"+"AddResponse.java");
		fileWriter.write(data);
		fileWriter.close();
	}
	public void createResourceFolder()
	{
		String path1 = "src/main/resources/static";
		createDirectory(path1);
		String path2 = "src/main/resources/templates";
		createDirectory(path2);
	}
	public void createAppProperties(int i, String db_name, String username, String password) throws IOException
	{
		String str = EntityName;
		String path = "src/main/resources";
		createDirectory(path);
		String data = "server.port="+(8080+i)+"\r\n"
				+ "\r\n"
				+ "spring.datasource.url=jdbc:mysql://localhost:3306/"+db_name+"\r\n"
				+ "spring.datasource.username="+username+"\r\n"
				+ "spring.datasource.password="+password+"\r\n"
				+ "spring.jpa.hibernate.ddl-auto=update\r\n"
				+ "\r\n"
				+ "## Hibernate Properties\r\n"
				+ "# The SQL dialect makes Hibernate generate better SQL for the chosen database\r\n"
				+ "spring.jpa.properties.hibernate.dialect = org.hibernate.dialect.MySQL5InnoDBDialect\r\n"
				+ "\r\n"
				+ "spring.application.name="+str.toUpperCase()+"-SERVICE\r\n"
				+ "\r\n"
				+ "eureka.client.serviceUrl.defaultZone  = http://localhost:8761/eureka\r\n"
				+ "eureka.client.register-with-eureka=true\r\n"
				+ "eureka.client.fetch-registry=true\r\n"
				+ "eureka.instance.hostname=localhost"
				+ "\r\n"
				+ "resilience4j.circuitbreaker.instances."+(str.substring(0, 1).toUpperCase() + str.substring(1).toLowerCase())+".register-health-indicator= true\r\n"
				+ "resilience4j.circuitbreaker.instances."+(str.substring(0, 1).toUpperCase() + str.substring(1).toLowerCase())+".event-consumer-buffer-size= 10\r\n"
				+ "resilience4j.circuitbreaker.instances."+(str.substring(0, 1).toUpperCase() + str.substring(1).toLowerCase())+".failure-rate-threshold= 50\r\n"
				+ "resilience4j.circuitbreaker.instances."+(str.substring(0, 1).toUpperCase() + str.substring(1).toLowerCase())+".minimum-number-of-calls= 5\r\n"
				+ "resilience4j.circuitbreaker.instances."+(str.substring(0, 1).toUpperCase() + str.substring(1).toLowerCase())+".automatic-transition-from-open-to-half-open-enabled=true\r\n"
				+ "resilience4j.circuitbreaker.instances."+(str.substring(0, 1).toUpperCase() + str.substring(1).toLowerCase())+".wait-duration-in-open-state=5s\r\n"
				+ "resilience4j.circuitbreaker.instances."+(str.substring(0, 1).toUpperCase() + str.substring(1).toLowerCase())+".permitted-number-of-calls-in-half-open-state=3\r\n"
				+ "resilience4j.circuitbreaker.instances."+(str.substring(0, 1).toUpperCase() + str.substring(1).toLowerCase())+".sliding-window-size=10\r\n"
				+ "resilience4j.circuitbreaker.instances."+(str.substring(0, 1).toUpperCase() + str.substring(1).toLowerCase())+".sliding-window-type=COUNT_BASED";
		FileWriter fileWriter = new FileWriter(PATH+"/"+path+"/application.properties");
		fileWriter.write(data);
		fileWriter.close();
	}
	public void createEntityAppTests() throws IOException
	{
		String str = EntityName;
		String path = "src/test/java/com/example/demo";
		createDirectory(path);
		String data = "package com.example.demo;\r\n"
				+ "\r\n"
				+ "import org.junit.jupiter.api.Test;\r\n"
				+ "import org.springframework.boot.test.context.SpringBootTest;\r\n"
				+ "\r\n"
				+ "@SpringBootTest\r\n"
				+ "class "+(str.substring(0, 1).toUpperCase()+str.substring(1))+"ApplicationTests {\r\n"
				+ "\r\n"
				+ "	@Test\r\n"
				+ "	void contextLoads() {\r\n"
				+ "	}\r\n"
				+ "\r\n"
				+ "}\r\n"
				+ "";
		FileWriter fileWriter = new FileWriter(PATH+"/"+path+"/"+(str.substring(0, 1).toUpperCase()+str.substring(1))+"ApplicationTests.java");
		fileWriter.write(data);
		fileWriter.close();
	}
	public void createTargetFolder() throws IOException
	{
		String path = "target/classes";
		createDirectory(path);
	}
	public void createmvnfolder()
	{
		String path = ".mvn";
		createDirectory(path);
	}
	public void setting1() throws IOException
	{
		String path = ".settings";
		createDirectory(path);
		String data = "eclipse.preferences.version=1\r\n"
				+ "encoding//src/main/java=UTF-8\r\n"
				+ "encoding//src/main/resources=UTF-8\r\n"
				+ "encoding//src/test/java=UTF-8\r\n"
				+ "encoding/<project>=UTF-8\r\n"
				+ "";
		FileWriter fileWriter = new FileWriter(PATH+"/"+path+"/org.eclipse.core.resources.prefs");
		fileWriter.write(data);
		fileWriter.close();
	}
	public void setting2() throws IOException
	{
		String path = ".settings";
		createDirectory(path);
		String data = "eclipse.preferences.version=1\r\n"
				+ "org.eclipse.jdt.core.compiler.codegen.methodParameters=generate\r\n"
				+ "org.eclipse.jdt.core.compiler.codegen.targetPlatform=17\r\n"
				+ "org.eclipse.jdt.core.compiler.compliance=17\r\n"
				+ "org.eclipse.jdt.core.compiler.problem.enablePreviewFeatures=disabled\r\n"
				+ "org.eclipse.jdt.core.compiler.problem.forbiddenReference=warning\r\n"
				+ "org.eclipse.jdt.core.compiler.problem.reportPreviewFeatures=ignore\r\n"
				+ "org.eclipse.jdt.core.compiler.release=disabled\r\n"
				+ "org.eclipse.jdt.core.compiler.source=17";
		FileWriter fileWriter = new FileWriter(PATH+"/"+path+"/org.eclipse.jdt.core.prefs");
		fileWriter.write(data);
		fileWriter.close();
	}
	public void setting3() throws IOException
	{
		String path = ".settings";
		createDirectory(path);
		String data = "activeProfiles=pom.xml\r\n"
				+ "eclipse.preferences.version=1\r\n"
				+ "resolveWorkspaceProjects=true\r\n"
				+ "version=1\r\n"
				+ "";
		FileWriter fileWriter = new FileWriter(PATH+"/"+path+"/org.eclipse.m2e.core.prefs");
		fileWriter.write(data);
		fileWriter.close();
	}
	public void setting4() throws IOException
	{
		String path = ".settings";
		createDirectory(path);
		String data = "boot.validation.initialized=true\r\n"
				+ "eclipse.preferences.version=1";
		FileWriter fileWriter = new FileWriter(PATH+"/"+path+"/org.springframework.ide.eclipse.prefs");
		fileWriter.write(data);
		fileWriter.close();
	}
}
