package com.surprise;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

import com.surprise.APIGatewayCreation.CreateAPIGateway;
import com.surprise.AngularFiles.CreateAngularFiles;
import com.surprise.EntityCreation.CreateEntity;
import com.surprise.EntityCreation.CreateMainEntity;
import com.surprise.EntityCreation.CreateSubEntity;
import com.surprise.ServiceRegistryCreation.CreateServiceRegistry;
import com.surprise.handlingDB.DBCreation;


public class MainClass {
	
	public static void createServiceRegistry(String title) throws IOException
	{
		CreateServiceRegistry crs = new CreateServiceRegistry();
		String temp = crs.getPATH();
		crs.setPATH(title+"/"+temp);
		crs.createMainDirectory();
		crs.createPom();
		crs.createmvnwFile();
		crs.createHelpMdFile();
		crs.createProjectFile();
		crs.createGitIgnoreFile();
		crs.createClassPathFile();
		crs.createSegistyAppClass();
		crs.createServRegAppTests();
		crs.createAppProperties();
		crs.createTargetFolder();
		crs.createmvnfolder();
		crs.setting1();
		crs.setting2();
		crs.setting3();
		crs.setting4();
	}
	public static void createAPIGateway(String title, String[] entites) throws IOException
	{
		CreateAPIGateway crs = new CreateAPIGateway();
		String temp = crs.getPATH();
		crs.setPATH(title+"/"+temp);
		crs.createMainDirectory();
		crs.createPom();
		crs.createmvnwFile();
		crs.createHelpMdFile();
		crs.createProjectFile();
		crs.createGitIgnoreFile();
		crs.createClassPathFile();
		crs.createApiGatewayAppClass();
		crs.createApiGatewayAppTests();
		crs.createAppProperties(entites);
		crs.corsConfigurationClass();
		crs.createTargetFolder();
		crs.createmvnfolder();
		crs.setting1();
		crs.setting2();
		crs.setting3();
		crs.setting4();
	}
	public static void createEntity(int i, String name, String title, HashMap<String, String> props, String db_name, String user_name, String password) throws IOException
	{
		CreateEntity crs = new CreateEntity(title+"/"+name, props);
		crs.createMainDirectory();
		crs.setEntityName(name);
		crs.createPom();
		crs.createmvnwFile();
		crs.createHelpMdFile();
		crs.createProjectFile();
		crs.createGitIgnoreFile();
		crs.createClassPathFile();
		crs.createEntityAppClass();
		crs.createEntityEntityClass();
		crs.createEntityRepository();
		crs.createEntityImplementation();
		crs.createEntityService();
		crs.createEntityController();
		crs.createAddResponse();
		crs.createResourceFolder();
		crs.createAppProperties(i, db_name, user_name, password);
		crs.createEntityAppTests();
		crs.createTargetFolder();
		crs.createmvnfolder();
		crs.setting1();
		crs.setting2();
		crs.setting3();
		crs.setting4();
	}
	public static void createMainEntity(int i, String name, String title, HashMap<String, String> props, String db_name, String user_name, String password, String[] entityList) throws IOException
	{
		CreateMainEntity crs = new CreateMainEntity(title+"/"+name, props, entityList);
		crs.createMainDirectory();
		crs.setEntityName(name);
		crs.createPom();
		crs.createmvnwFile();
		crs.createHelpMdFile();
		crs.createProjectFile();
		crs.createGitIgnoreFile();
		crs.createClassPathFile();
		crs.createEntityAppClass();
		crs.createEntityEntityClass();
		crs.createEntityRepository();
		crs.createEntityImplementation();
		crs.createEntityService();
		crs.createEntityController();
		crs.createAddResponse();
		crs.createResourceFolder();
		crs.createAppProperties(i, db_name, user_name, password);
		crs.createEntityAppTests();
		crs.createTargetFolder();
		crs.createmvnfolder();
		crs.setting1();
		crs.setting2();
		crs.setting3();
		crs.setting4();
	}
	
	public static void createSubEntity(int i, String name, String title, HashMap<String, String> props, String db_name, String user_name, String password, String mainEntityName, HashMap<String, String> mainEntityprops) throws IOException
	{
		CreateSubEntity crs = new CreateSubEntity(title+"/"+name, props, mainEntityName, mainEntityprops);
		crs.createMainDirectory();
		crs.setEntityName(name);
		crs.createPom();
		crs.createmvnwFile();
		crs.createHelpMdFile();
		crs.createProjectFile();
		crs.createGitIgnoreFile();
		crs.createClassPathFile();
		crs.createEntityAppClass();
		crs.createMainEntityClass();
		crs.createEntityVOClass();
		crs.createEntityEntityClass();
		crs.createEntityRepository();
		crs.createEntityImplementation();
		crs.createEntityService();
		crs.createEntityController();
		crs.createAddResponse();
		crs.createResourceFolder();
		crs.createAppProperties(i, db_name, user_name, password);
		crs.createEntityAppTests();
		crs.createTargetFolder();
		crs.createmvnfolder();
		crs.setting1();
		crs.setting2();
		crs.setting3();
		crs.setting4();
	}
	
	public static void createAngularFiles(String name, String title, HashMap<String, String> props) throws IOException {
		CreateAngularFiles crs = new CreateAngularFiles(title+"/"+name, props);
		crs.createMainDirectory();
		crs.setEntityName(name);
		crs.createEntity();
		crs.createEntityService();
	}
	
	public static void createDataBase(String username, String password, String db_name) throws SQLException
	{
		DBCreation dbc = new DBCreation(username, password, db_name);
		dbc.createDB();
	}
	public static void main(String[] args) throws IOException, SQLException {
		// TODO Auto-generated method stub
		
		System.out.println("Hi "+System.getProperty("user.name"));
		
		System.out.println("We will now Automate the Microservice N entity creation");
		
		System.out.println("We request you to enter all names in small letters except for db username and pwd!");
		
		System.out.println("Please Enter your project Name:");
		
		Scanner sc = new Scanner(System.in);
		String title = sc.next();
		System.out.println("Please Let us know your Database name");
		String db_name = sc.next();
		System.out.println("Please Let us know your User name for Database connection");
		String user_name = sc.next();
		String password;
		System.out.println("Is your passord for your database Empty? Yes/No");
		String res = sc.next();
		if(res.equalsIgnoreCase("Yes"))
			password = "";
		else
		{
			System.out.println("Please Let us know your Password for Database connection");
			password = sc.next();
		}
		File file = new File(title);
		if(!file.exists())
		{
			file.mkdir();
		}
		System.out.println("Creating Service Registry.......");
		System.out.println("Here We Go!!!!!!!");
		createServiceRegistry(title);
		System.out.println("Service Registry Project Creation Over Over!!!!!!");
		System.out.println("So How many Entites you gonna use???");
		int total_entities = sc.nextInt();
		System.out.println(" Do you need to create Angular project also??, Say YES/NO");
		boolean angular = sc.next().equalsIgnoreCase("YES");
		if(total_entities==1)
		{
			String[] entity_names = new String[total_entities];
			String xd = "";
			for(int i=0; i<total_entities; i++)
			{
				System.out.println(""+(i+1)+". ");
				xd = sc.next().strip();
				entity_names[i] = xd.substring(0, 1).toUpperCase() + xd.substring(1);
				System.out.println();
			}
			System.out.println("Creating APIGateway..........");
			System.out.println("Here We Go!!!!!!!!");
			createAPIGateway(title, entity_names);
			System.out.println("APIGateway Project Creation Over Over!!!!!!");
			System.out.println("Come on Let's Jump to Entity Project Creation");
			
			
			
			for(int i=0; i< total_entities; i++)
			{
				String name = entity_names[i];
				System.out.println("Creating Entity "+name);
				System.out.println("Wow!!! What a wonderful Name!!!");
				System.out.println("How many properties you wanna set to your entity?");
				int number = sc.nextInt();
				System.out.println("Nice Job!!!!");
				HashMap<String, String> props = new HashMap<>();
				String prop_name = "", prop_type="";
				System.out.println("First property name is id and type is int by default");
				for(int j=0; j<number; j++)
				{
					if(j==0)
					{
						prop_name = "id";
						prop_type = "int";
					}
					else
					{
						System.out.println("Enter Property name: ");
						prop_name = sc.next().strip();
						System.out.println("Enter Property type: ");
						prop_type = sc.next().strip();
						if(prop_type.toLowerCase().equals("string"))
						{
							prop_type = "String";
						}
					}
					props.put(prop_name, prop_type);
				}
				createEntity(i, name, title, props, db_name, user_name, password);
				if(angular)
					createAngularFiles(name, title, props);
			}
		}
		else
		{
			System.out.println("Do you want to establish a relationship betweenn your entities");
			System.out.println("Yes/No");
			String resp = sc.next();
			System.out.println("Fine Proceed with entering your entity names");
			if(resp.equalsIgnoreCase("No"))
			{
				String[] entity_names = new String[total_entities];
				String xd = "";
				for(int i=0; i<total_entities; i++)
				{
					System.out.println(""+(i+1)+". ");
					xd = sc.next().strip();
					entity_names[i] = xd.substring(0, 1).toUpperCase() + xd.substring(1);
					System.out.println();
				}
				System.out.println("Creating APIGateway..........");
				System.out.println("Here We Go!!!!!!!!");
				createAPIGateway(title, entity_names);
				System.out.println("APIGateway Project Creation Over Over!!!!!!");
				System.out.println("Come on Let's Jump to Entity Project Creation");
				
				
				
				for(int i=0; i< total_entities; i++)
				{
					String name = entity_names[i];
					System.out.println("Creating Entity "+name);
					System.out.println("Wow!!! What a wonderful Name!!!");
					System.out.println("How many properties you wanna set to your entity?");
					int number = sc.nextInt();
					System.out.println("Nice Job!!!!");
					HashMap<String, String> props = new HashMap<>();
					String prop_name = "", prop_type="";
					System.out.println("First property name is id and type is int by default");
					for(int j=0; j<number; j++)
					{
						if(j==0)
						{
							prop_name = "id";
							prop_type = "int";
						}
						else
						{
							System.out.println("Enter Property name: ");
							prop_name = sc.next().strip();
							System.out.println("Enter Property type: ");
							prop_type = sc.next().strip();
							if(prop_type.toLowerCase().equals("string"))
							{
								prop_type = "String";
							}
						}
						props.put(prop_name, prop_type);
					}
					createEntity(i, name, title, props, db_name, user_name, password);
					if(angular)
						createAngularFiles(name, title, props);
				}
			}
				else
				{
					String[] entity_names = new String[total_entities];
					String xd = "";
					System.out.println("Please Note that first entity will be considered as Parent Entity By default");
					for(int i=0; i<total_entities; i++)
					{
						System.out.println(""+(i+1)+". ");
						xd = sc.next().strip();
						entity_names[i] = xd.substring(0, 1).toUpperCase() + xd.substring(1);
						System.out.println();
					}
					System.out.println("Creating APIGateway..........");
					System.out.println("Here We Go!!!!!!!!");
					createAPIGateway(title, entity_names);
					System.out.println("APIGateway Project Creation Over Over!!!!!!");
					System.out.println("Come on Let's Jump to Entity Project Creation");
					String[] other_entites = new String[total_entities-1];
					for(int i=1; i<total_entities; i++)
					{
						other_entites[i-1] = entity_names[i];
					}
					
					HashMap<String, String> mainEntityprops = new HashMap<>();
					for(int i=0; i< total_entities; i++)
					{
						if(i==0)
						{
							String name = entity_names[i];
							System.out.println("Creating Entity "+name);
							System.out.println("Wow!!! What a wonderful Name!!!");
							System.out.println("How many properties you wanna set to your entity including id and foregin key ids?");
							System.out.println("Please enter a number greater than "+entity_names.length);
							int number = sc.nextInt();
							System.out.println("Nice Job!!!!");
							HashMap<String, String> props = new HashMap<>();
							String prop_name = "", prop_type="";
							System.out.println("First property name is id and type is int by default");
							System.out.println("And the Foreign Keys are also assigned by default");
							System.out.println("Please Enter the remaining properties");
							for(int j=0; j<number-other_entites.length; j++)
							{
								if(j==0)
								{
									prop_name = "id";
									prop_type = "int";
								}
								else
								{
									System.out.println("Enter Property name: ");
									prop_name = sc.next().strip();
									System.out.println("Enter Property type:  ");
									prop_type = sc.next().strip();
									if(prop_type.toLowerCase().equals("string"))
									{
										prop_type = "String";
									}
								}
								props.put(prop_name, prop_type);
							}
							for(int j=1; j<total_entities; j++)
							{
								props.put(entity_names[j].toLowerCase()+"id", "int");
							}
							createMainEntity(i, name, title, props, db_name, user_name, password, other_entites);
							if(angular)
								createAngularFiles(name, title, props);
							mainEntityprops = props;
						}
						else {
							String name = entity_names[i];
							System.out.println("Creating Entity "+name);
							System.out.println("Wow!!! What a wonderful Name!!!");
							System.out.println("How many properties you wanna set to your entity including id?");
							int number = sc.nextInt();
							System.out.println("Nice Job!!!!");
							HashMap<String, String> props = new HashMap<>();
							String prop_name = "", prop_type="";
							System.out.println("First property name is id and type is int by default");
							System.out.println("Enter the remaining properties id");
							for(int j=0; j<number; j++)
							{
								if(j==0)
								{
									prop_name = "id";
									prop_type = "int";
								}
								else
								{
									System.out.println("Enter Property name: ");
									prop_name = sc.next().strip();
									System.out.println("Enter Property type: ");
									prop_type = sc.next().strip();
									if(prop_type.toLowerCase().equals("string"))
									{
										prop_type = "String";
									}
								}
								props.put(prop_name, prop_type);
							}
							createSubEntity(i, name, title, props, db_name, user_name, password, entity_names[0], mainEntityprops);
							if(angular)
								createAngularFiles(name, title, props);
						}
					}
				}
			}
		System.out.println("Excellent Work! All Entites are created!!!!");
		System.out.println("Time for DB Setup");
		createDataBase(user_name, password, db_name);
		System.out.println("DataBase Successfully Created");
		System.out.println("Project Setup Over!!!!!!!!!");
		System.out.println("Use Me Again Thanks!");
		System.out.println("Bye");
		sc.close();
	}

}
