package com.surprise.handlingDB;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class DBCreation {
	
	private String username;
	private String password;
	private String db_name;


	public String getUsername() {
		return username;
	}


	public void setUsername(String username) {
		this.username = username;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public String getDb_name() {
		return db_name;
	}


	public void setDb_name(String db_name) {
		this.db_name = db_name;
	}


	public DBCreation(String username, String password, String db_name) {
		this.username = username;
		this.password = password;
		this.db_name = db_name;
	}

	public void createDB() throws SQLException
	{
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost/?user="+username+"&password="+password);
		Statement st = con.createStatement();
		String sql = "CREATE DATABASE IF NOT EXISTS "+db_name;
		st.executeUpdate(sql);
		System.out.println("DataBase Created");
	}
}
