package com.surprise.AngularFiles;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;

public class CreateAngularFiles {
	private String PATH;
	private String EntityName;
	public String getEntityName() {
		return EntityName;
	}

	public void setEntityName(String entityName) {
		EntityName = entityName;
	}
	private HashMap<String, String> props;
	
	
	

	public CreateAngularFiles(String pATH, HashMap<String, String> props) {
		PATH = pATH;
		this.props = props;
	}

	public HashMap<String, String> getProps() {
		return props;
	}

	public void setProps(HashMap<String, String> props) {
		this.props = props;
	}

	public String getPATH() {
		return PATH;
	}

	public void setPATH(String PATH) {
		this.PATH = PATH;
	}
	
	public void createMainDirectory()
	{
		String path = PATH;
		String[] arr = path.split("/");
		if(arr.length>1)
		{
			String[] strarr = new String[arr.length];
			for(int i=0; i<arr.length; i++)
			{
				if(i==0)
					strarr[i] = arr[i];
				else
					strarr[i] = strarr[i-1] + "/" + arr[i];
				//System.out.println(PATH+"/"+strarr[i]);
				File directory = new File(strarr[i]);
				if(!directory.exists())
				{
					directory.mkdir();
				}
			}
		}
		else
		{
			File directory = new File(PATH+"/"+path);
			if(!directory.exists())
			{
				directory.mkdir();
			}
		}
	}
	public void createEntity() throws IOException {
		String str = EntityName.toLowerCase();
		String data = "export class "+(str.substring(0, 1).toUpperCase()+str.substring(1))+" {\r\n";
		for(String name: props.keySet())
		{
			if(props.get(name)=="int")
				data += "    "+name+": number;\r\n";
			else
				data += "    "+name+": string;\r\n";
		}
		data += "}";
		FileWriter filewriter = new FileWriter(PATH+"/"+str+".ts");
		filewriter.write(data);
		filewriter.close();
	}
	public void createEntityService() throws IOException{
		String str = EntityName.toLowerCase();
		String data = "import { HttpClient } from '@angular/common/http';\r\n"
				+ "import { Injectable } from '@angular/core';\r\n"
				+ "import { Observable } from 'rxjs'\r\n"
				+ "import { "+(str.substring(0, 1).toUpperCase()+str.substring(1))+" } from './"+str+"';\r\n"
				+ "\r\n"
				+ "@Injectable({\r\n"
				+ "  providedIn: 'root'\r\n"
				+ "})\r\n"
				+ "export class "+(str.substring(0, 1).toUpperCase()+str.substring(1))+"Service {\r\n"
				+ "\r\n"
				+ "  private baseURL = \"http://localhost:9000/"+str.toLowerCase()+"/\";\r\n"
				+ "\r\n"
				+ "  constructor(private httpClient: HttpClient) { }"
				+ "\r\n"
				+ "  get"+(str.substring(0, 1).toUpperCase()+str.substring(1))+"sList(): Observable<"+(str.substring(0, 1).toUpperCase()+str.substring(1))+"[]>{\r\n"
				+ "    return this.httpClient.get<"+(str.substring(0, 1).toUpperCase()+str.substring(1))+"[]>(`${this.baseURL}`);\r\n"
				+ "  }\r\n"
				+ "\r\n"
				+ "  add"+(str.substring(0, 1).toUpperCase()+str.substring(1))+"("+str.toLowerCase()+": "+(str.substring(0, 1).toUpperCase()+str.substring(1))+"): Observable<"+(str.substring(0, 1).toUpperCase()+str.substring(1))+">{\r\n"
				+ "    return this.httpClient.post<"+(str.substring(0, 1).toUpperCase()+str.substring(1))+">(`${this.baseURL}`, "+str.toLowerCase()+");\r\n"
				+ "  }\r\n"
				+ "\r\n"
				+ "  get"+(str.substring(0, 1).toUpperCase()+str.substring(1))+"ByID(id: number): Observable<"+(str.substring(0, 1).toUpperCase()+str.substring(1))+">{\r\n"
				+ "    return this.httpClient.get<"+(str.substring(0, 1).toUpperCase()+str.substring(1))+">(`${this.baseURL}/${id}`);\r\n"
				+ "  }\r\n"
				+ "\r\n"
				+ "  update"+(str.substring(0, 1).toUpperCase()+str.substring(1))+"(id: number, "+str.toLowerCase()+": "+(str.substring(0, 1).toUpperCase()+str.substring(1))+"): Observable<"+(str.substring(0, 1).toUpperCase()+str.substring(1))+">{\r\n"
				+ "    return this.httpClient.put<"+(str.substring(0, 1).toUpperCase()+str.substring(1))+">(`${this.baseURL}/${id}`, "+str.toLowerCase()+");\r\n"
				+ "  }\r\n"
				+ "\r\n"
				+ "  deleteEmployee(id: number): Observable<string>{\r\n"
				+ "    return this.httpClient.delete<string>(`${this.baseURL}/${id}`);\r\n"
				+ "  }\r\n"
				+ "\r\n"
				+ "}";
		FileWriter filewriter = new FileWriter(PATH+"/"+str+".service.ts");
		filewriter.write(data);
		filewriter.close();
	}
}
