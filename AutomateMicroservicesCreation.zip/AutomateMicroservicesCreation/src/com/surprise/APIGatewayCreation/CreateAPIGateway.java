package com.surprise.APIGatewayCreation;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class CreateAPIGateway {
	
	private String PATH = "APIGateway";
	
	public String getPATH() {
		return PATH;
	}

	public void setPATH(String pATH) {
		PATH = pATH;
	}
	
	public void createMainDirectory()
	{
		String path = PATH;
		String[] arr = path.split("/");
		if(arr.length>1)
		{
			String[] strarr = new String[arr.length];
			for(int i=0; i<arr.length; i++)
			{
				if(i==0)
					strarr[i] = arr[i];
				else
					strarr[i] = strarr[i-1] + "/" + arr[i];
				//System.out.println(PATH+"/"+strarr[i]);
				File directory = new File(strarr[i]);
				if(!directory.exists())
				{
					directory.mkdir();
				}
			}
		}
		else
		{
			File directory = new File(PATH+"/"+path);
			if(!directory.exists())
			{
				directory.mkdir();
			}
		}
	}
	
	public void createPom() throws IOException {
		// TODO Auto-generated method stub
		String data = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n"
				+ "<project xmlns=\"http://maven.apache.org/POM/4.0.0\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"\r\n"
				+ "	xsi:schemaLocation=\"http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd\">\r\n"
				+ "	<modelVersion>4.0.0</modelVersion>\r\n"
				+ "	<parent>\r\n"
				+ "		<groupId>org.springframework.boot</groupId>\r\n"
				+ "		<artifactId>spring-boot-starter-parent</artifactId>\r\n"
				+ "		<version>2.7.3</version>\r\n"
				+ "		<relativePath/> <!-- lookup parent from repository -->\r\n"
				+ "	</parent>\r\n"
				+ "	<groupId>com.example</groupId>\r\n"
				+ "	<artifactId>APIGateway</artifactId>\r\n"
				+ "	<version>0.0.1-SNAPSHOT</version>\r\n"
				+ "	<name>APIGateway</name>\r\n"
				+ "	<description>Demo project for Spring Boot</description>\r\n"
				+ "	<properties>\r\n"
				+ "		<java.version>17</java.version>\r\n"
				+ "		<spring-cloud.version>2021.0.3</spring-cloud.version>\r\n"
				+ "	</properties>\r\n"
				+ "	<dependencies>\r\n"
				+ "		<dependency>\r\n"
				+ "			<groupId>org.springframework.boot</groupId>\r\n"
				+ "			<artifactId>spring-boot-starter-actuator</artifactId>\r\n"
				+ "		</dependency>\r\n"
				+ "		<dependency>\r\n"
				+ "			<groupId>org.springframework.cloud</groupId>\r\n"
				+ "			<artifactId>spring-cloud-starter-gateway</artifactId>\r\n"
				+ "		</dependency>\r\n"
				+ "		<dependency>\r\n"
				+ "			<groupId>org.springframework.cloud</groupId>\r\n"
				+ "			<artifactId>spring-cloud-starter-netflix-eureka-client</artifactId>\r\n"
				+ "		</dependency>\r\n"
				+ "\r\n"
				+ "		<dependency>\r\n"
				+ "			<groupId>org.springframework.boot</groupId>\r\n"
				+ "			<artifactId>spring-boot-starter-test</artifactId>\r\n"
				+ "			<scope>test</scope>\r\n"
				+ "		</dependency>\r\n"
				+ "	</dependencies>\r\n"
				+ "	<dependencyManagement>\r\n"
				+ "		<dependencies>\r\n"
				+ "			<dependency>\r\n"
				+ "				<groupId>org.springframework.cloud</groupId>\r\n"
				+ "				<artifactId>spring-cloud-dependencies</artifactId>\r\n"
				+ "				<version>${spring-cloud.version}</version>\r\n"
				+ "				<type>pom</type>\r\n"
				+ "				<scope>import</scope>\r\n"
				+ "			</dependency>\r\n"
				+ "		</dependencies>\r\n"
				+ "	</dependencyManagement>\r\n"
				+ "\r\n"
				+ "	<build>\r\n"
				+ "		<plugins>\r\n"
				+ "			<plugin>\r\n"
				+ "				<groupId>org.springframework.boot</groupId>\r\n"
				+ "				<artifactId>spring-boot-maven-plugin</artifactId>\r\n"
				+ "			</plugin>\r\n"
				+ "		</plugins>\r\n"
				+ "	</build>\r\n"
				+ "\r\n"
				+ "</project>\r\n"
				+ "";
		FileWriter fileWriter = new FileWriter(PATH+"/pom.xml");
		fileWriter.write(data);
		fileWriter.close();
	}
	
	public void createmvnwFile() throws IOException
	{
		String data = "#!/bin/sh\r\n"
				+ "# ----------------------------------------------------------------------------\r\n"
				+ "# Licensed to the Apache Software Foundation (ASF) under one\r\n"
				+ "# or more contributor license agreements.  See the NOTICE file\r\n"
				+ "# distributed with this work for additional information\r\n"
				+ "# regarding copyright ownership.  The ASF licenses this file\r\n"
				+ "# to you under the Apache License, Version 2.0 (the\r\n"
				+ "# \"License\"); you may not use this file except in compliance\r\n"
				+ "# with the License.  You may obtain a copy of the License at\r\n"
				+ "#\r\n"
				+ "#    https://www.apache.org/licenses/LICENSE-2.0\r\n"
				+ "#\r\n"
				+ "# Unless required by applicable law or agreed to in writing,\r\n"
				+ "# software distributed under the License is distributed on an\r\n"
				+ "# \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY\r\n"
				+ "# KIND, either express or implied.  See the License for the\r\n"
				+ "# specific language governing permissions and limitations\r\n"
				+ "# under the License.\r\n"
				+ "# ----------------------------------------------------------------------------\r\n"
				+ "\r\n"
				+ "# ----------------------------------------------------------------------------\r\n"
				+ "# Maven Start Up Batch script\r\n"
				+ "#\r\n"
				+ "# Required ENV vars:\r\n"
				+ "# ------------------\r\n"
				+ "#   JAVA_HOME - location of a JDK home dir\r\n"
				+ "#\r\n"
				+ "# Optional ENV vars\r\n"
				+ "# -----------------\r\n"
				+ "#   M2_HOME - location of maven2's installed home dir\r\n"
				+ "#   MAVEN_OPTS - parameters passed to the Java VM when running Maven\r\n"
				+ "#     e.g. to debug Maven itself, use\r\n"
				+ "#       set MAVEN_OPTS=-Xdebug -Xrunjdwp:transport=dt_socket,server=y,suspend=y,address=8000\r\n"
				+ "#   MAVEN_SKIP_RC - flag to disable loading of mavenrc files\r\n"
				+ "# ----------------------------------------------------------------------------\r\n"
				+ "\r\n"
				+ "if [ -z \"$MAVEN_SKIP_RC\" ] ; then\r\n"
				+ "\r\n"
				+ "  if [ -f /usr/local/etc/mavenrc ] ; then\r\n"
				+ "    . /usr/local/etc/mavenrc\r\n"
				+ "  fi\r\n"
				+ "\r\n"
				+ "  if [ -f /etc/mavenrc ] ; then\r\n"
				+ "    . /etc/mavenrc\r\n"
				+ "  fi\r\n"
				+ "\r\n"
				+ "  if [ -f \"$HOME/.mavenrc\" ] ; then\r\n"
				+ "    . \"$HOME/.mavenrc\"\r\n"
				+ "  fi\r\n"
				+ "\r\n"
				+ "fi\r\n"
				+ "\r\n"
				+ "# OS specific support.  $var _must_ be set to either true or false.\r\n"
				+ "cygwin=false;\r\n"
				+ "darwin=false;\r\n"
				+ "mingw=false\r\n"
				+ "case \"`uname`\" in\r\n"
				+ "  CYGWIN*) cygwin=true ;;\r\n"
				+ "  MINGW*) mingw=true;;\r\n"
				+ "  Darwin*) darwin=true\r\n"
				+ "    # Use /usr/libexec/java_home if available, otherwise fall back to /Library/Java/Home\r\n"
				+ "    # See https://developer.apple.com/library/mac/qa/qa1170/_index.html\r\n"
				+ "    if [ -z \"$JAVA_HOME\" ]; then\r\n"
				+ "      if [ -x \"/usr/libexec/java_home\" ]; then\r\n"
				+ "        export JAVA_HOME=\"`/usr/libexec/java_home`\"\r\n"
				+ "      else\r\n"
				+ "        export JAVA_HOME=\"/Library/Java/Home\"\r\n"
				+ "      fi\r\n"
				+ "    fi\r\n"
				+ "    ;;\r\n"
				+ "esac\r\n"
				+ "\r\n"
				+ "if [ -z \"$JAVA_HOME\" ] ; then\r\n"
				+ "  if [ -r /etc/gentoo-release ] ; then\r\n"
				+ "    JAVA_HOME=`java-config --jre-home`\r\n"
				+ "  fi\r\n"
				+ "fi\r\n"
				+ "\r\n"
				+ "if [ -z \"$M2_HOME\" ] ; then\r\n"
				+ "  ## resolve links - $0 may be a link to maven's home\r\n"
				+ "  PRG=\"$0\"\r\n"
				+ "\r\n"
				+ "  # need this for relative symlinks\r\n"
				+ "  while [ -h \"$PRG\" ] ; do\r\n"
				+ "    ls=`ls -ld \"$PRG\"`\r\n"
				+ "    link=`expr \"$ls\" : '.*-> \\(.*\\)$'`\r\n"
				+ "    if expr \"$link\" : '/.*' > /dev/null; then\r\n"
				+ "      PRG=\"$link\"\r\n"
				+ "    else\r\n"
				+ "      PRG=\"`dirname \"$PRG\"`/$link\"\r\n"
				+ "    fi\r\n"
				+ "  done\r\n"
				+ "\r\n"
				+ "  saveddir=`pwd`\r\n"
				+ "\r\n"
				+ "  M2_HOME=`dirname \"$PRG\"`/..\r\n"
				+ "\r\n"
				+ "  # make it fully qualified\r\n"
				+ "  M2_HOME=`cd \"$M2_HOME\" && pwd`\r\n"
				+ "\r\n"
				+ "  cd \"$saveddir\"\r\n"
				+ "  # echo Using m2 at $M2_HOME\r\n"
				+ "fi\r\n"
				+ "\r\n"
				+ "# For Cygwin, ensure paths are in UNIX format before anything is touched\r\n"
				+ "if $cygwin ; then\r\n"
				+ "  [ -n \"$M2_HOME\" ] &&\r\n"
				+ "    M2_HOME=`cygpath --unix \"$M2_HOME\"`\r\n"
				+ "  [ -n \"$JAVA_HOME\" ] &&\r\n"
				+ "    JAVA_HOME=`cygpath --unix \"$JAVA_HOME\"`\r\n"
				+ "  [ -n \"$CLASSPATH\" ] &&\r\n"
				+ "    CLASSPATH=`cygpath --path --unix \"$CLASSPATH\"`\r\n"
				+ "fi\r\n"
				+ "\r\n"
				+ "# For Mingw, ensure paths are in UNIX format before anything is touched\r\n"
				+ "if $mingw ; then\r\n"
				+ "  [ -n \"$M2_HOME\" ] &&\r\n"
				+ "    M2_HOME=\"`(cd \"$M2_HOME\"; pwd)`\"\r\n"
				+ "  [ -n \"$JAVA_HOME\" ] &&\r\n"
				+ "    JAVA_HOME=\"`(cd \"$JAVA_HOME\"; pwd)`\"\r\n"
				+ "fi\r\n"
				+ "\r\n"
				+ "if [ -z \"$JAVA_HOME\" ]; then\r\n"
				+ "  javaExecutable=\"`which javac`\"\r\n"
				+ "  if [ -n \"$javaExecutable\" ] && ! [ \"`expr \\\"$javaExecutable\\\" : '\\([^ ]*\\)'`\" = \"no\" ]; then\r\n"
				+ "    # readlink(1) is not available as standard on Solaris 10.\r\n"
				+ "    readLink=`which readlink`\r\n"
				+ "    if [ ! `expr \"$readLink\" : '\\([^ ]*\\)'` = \"no\" ]; then\r\n"
				+ "      if $darwin ; then\r\n"
				+ "        javaHome=\"`dirname \\\"$javaExecutable\\\"`\"\r\n"
				+ "        javaExecutable=\"`cd \\\"$javaHome\\\" && pwd -P`/javac\"\r\n"
				+ "      else\r\n"
				+ "        javaExecutable=\"`readlink -f \\\"$javaExecutable\\\"`\"\r\n"
				+ "      fi\r\n"
				+ "      javaHome=\"`dirname \\\"$javaExecutable\\\"`\"\r\n"
				+ "      javaHome=`expr \"$javaHome\" : '\\(.*\\)/bin'`\r\n"
				+ "      JAVA_HOME=\"$javaHome\"\r\n"
				+ "      export JAVA_HOME\r\n"
				+ "    fi\r\n"
				+ "  fi\r\n"
				+ "fi\r\n"
				+ "\r\n"
				+ "if [ -z \"$JAVACMD\" ] ; then\r\n"
				+ "  if [ -n \"$JAVA_HOME\"  ] ; then\r\n"
				+ "    if [ -x \"$JAVA_HOME/jre/sh/java\" ] ; then\r\n"
				+ "      # IBM's JDK on AIX uses strange locations for the executables\r\n"
				+ "      JAVACMD=\"$JAVA_HOME/jre/sh/java\"\r\n"
				+ "    else\r\n"
				+ "      JAVACMD=\"$JAVA_HOME/bin/java\"\r\n"
				+ "    fi\r\n"
				+ "  else\r\n"
				+ "    JAVACMD=\"`\\\\unset -f command; \\\\command -v java`\"\r\n"
				+ "  fi\r\n"
				+ "fi\r\n"
				+ "\r\n"
				+ "if [ ! -x \"$JAVACMD\" ] ; then\r\n"
				+ "  echo \"Error: JAVA_HOME is not defined correctly.\" >&2\r\n"
				+ "  echo \"  We cannot execute $JAVACMD\" >&2\r\n"
				+ "  exit 1\r\n"
				+ "fi\r\n"
				+ "\r\n"
				+ "if [ -z \"$JAVA_HOME\" ] ; then\r\n"
				+ "  echo \"Warning: JAVA_HOME environment variable is not set.\"\r\n"
				+ "fi\r\n"
				+ "\r\n"
				+ "CLASSWORLDS_LAUNCHER=org.codehaus.plexus.classworlds.launcher.Launcher\r\n"
				+ "\r\n"
				+ "# traverses directory structure from process work directory to filesystem root\r\n"
				+ "# first directory with .mvn subdirectory is considered project base directory\r\n"
				+ "find_maven_basedir() {\r\n"
				+ "\r\n"
				+ "  if [ -z \"$1\" ]\r\n"
				+ "  then\r\n"
				+ "    echo \"Path not specified to find_maven_basedir\"\r\n"
				+ "    return 1\r\n"
				+ "  fi\r\n"
				+ "\r\n"
				+ "  basedir=\"$1\"\r\n"
				+ "  wdir=\"$1\"\r\n"
				+ "  while [ \"$wdir\" != '/' ] ; do\r\n"
				+ "    if [ -d \"$wdir\"/.mvn ] ; then\r\n"
				+ "      basedir=$wdir\r\n"
				+ "      break\r\n"
				+ "    fi\r\n"
				+ "    # workaround for JBEAP-8937 (on Solaris 10/Sparc)\r\n"
				+ "    if [ -d \"${wdir}\" ]; then\r\n"
				+ "      wdir=`cd \"$wdir/..\"; pwd`\r\n"
				+ "    fi\r\n"
				+ "    # end of workaround\r\n"
				+ "  done\r\n"
				+ "  echo \"${basedir}\"\r\n"
				+ "}\r\n"
				+ "\r\n"
				+ "# concatenates all lines of a file\r\n"
				+ "concat_lines() {\r\n"
				+ "  if [ -f \"$1\" ]; then\r\n"
				+ "    echo \"$(tr -s '\\n' ' ' < \"$1\")\"\r\n"
				+ "  fi\r\n"
				+ "}\r\n"
				+ "\r\n"
				+ "BASE_DIR=`find_maven_basedir \"$(pwd)\"`\r\n"
				+ "if [ -z \"$BASE_DIR\" ]; then\r\n"
				+ "  exit 1;\r\n"
				+ "fi\r\n"
				+ "\r\n"
				+ "##########################################################################################\r\n"
				+ "# Extension to allow automatically downloading the maven-wrapper.jar from Maven-central\r\n"
				+ "# This allows using the maven wrapper in projects that prohibit checking in binary data.\r\n"
				+ "##########################################################################################\r\n"
				+ "if [ -r \"$BASE_DIR/.mvn/wrapper/maven-wrapper.jar\" ]; then\r\n"
				+ "    if [ \"$MVNW_VERBOSE\" = true ]; then\r\n"
				+ "      echo \"Found .mvn/wrapper/maven-wrapper.jar\"\r\n"
				+ "    fi\r\n"
				+ "else\r\n"
				+ "    if [ \"$MVNW_VERBOSE\" = true ]; then\r\n"
				+ "      echo \"Couldn't find .mvn/wrapper/maven-wrapper.jar, downloading it ...\"\r\n"
				+ "    fi\r\n"
				+ "    if [ -n \"$MVNW_REPOURL\" ]; then\r\n"
				+ "      jarUrl=\"$MVNW_REPOURL/org/apache/maven/wrapper/maven-wrapper/3.1.0/maven-wrapper-3.1.0.jar\"\r\n"
				+ "    else\r\n"
				+ "      jarUrl=\"https://repo.maven.apache.org/maven2/org/apache/maven/wrapper/maven-wrapper/3.1.0/maven-wrapper-3.1.0.jar\"\r\n"
				+ "    fi\r\n"
				+ "    while IFS=\"=\" read key value; do\r\n"
				+ "      case \"$key\" in (wrapperUrl) jarUrl=\"$value\"; break ;;\r\n"
				+ "      esac\r\n"
				+ "    done < \"$BASE_DIR/.mvn/wrapper/maven-wrapper.properties\"\r\n"
				+ "    if [ \"$MVNW_VERBOSE\" = true ]; then\r\n"
				+ "      echo \"Downloading from: $jarUrl\"\r\n"
				+ "    fi\r\n"
				+ "    wrapperJarPath=\"$BASE_DIR/.mvn/wrapper/maven-wrapper.jar\"\r\n"
				+ "    if $cygwin; then\r\n"
				+ "      wrapperJarPath=`cygpath --path --windows \"$wrapperJarPath\"`\r\n"
				+ "    fi\r\n"
				+ "\r\n"
				+ "    if command -v wget > /dev/null; then\r\n"
				+ "        if [ \"$MVNW_VERBOSE\" = true ]; then\r\n"
				+ "          echo \"Found wget ... using wget\"\r\n"
				+ "        fi\r\n"
				+ "        if [ -z \"$MVNW_USERNAME\" ] || [ -z \"$MVNW_PASSWORD\" ]; then\r\n"
				+ "            wget \"$jarUrl\" -O \"$wrapperJarPath\" || rm -f \"$wrapperJarPath\"\r\n"
				+ "        else\r\n"
				+ "            wget --http-user=$MVNW_USERNAME --http-password=$MVNW_PASSWORD \"$jarUrl\" -O \"$wrapperJarPath\" || rm -f \"$wrapperJarPath\"\r\n"
				+ "        fi\r\n"
				+ "    elif command -v curl > /dev/null; then\r\n"
				+ "        if [ \"$MVNW_VERBOSE\" = true ]; then\r\n"
				+ "          echo \"Found curl ... using curl\"\r\n"
				+ "        fi\r\n"
				+ "        if [ -z \"$MVNW_USERNAME\" ] || [ -z \"$MVNW_PASSWORD\" ]; then\r\n"
				+ "            curl -o \"$wrapperJarPath\" \"$jarUrl\" -f\r\n"
				+ "        else\r\n"
				+ "            curl --user $MVNW_USERNAME:$MVNW_PASSWORD -o \"$wrapperJarPath\" \"$jarUrl\" -f\r\n"
				+ "        fi\r\n"
				+ "\r\n"
				+ "    else\r\n"
				+ "        if [ \"$MVNW_VERBOSE\" = true ]; then\r\n"
				+ "          echo \"Falling back to using Java to download\"\r\n"
				+ "        fi\r\n"
				+ "        javaClass=\"$BASE_DIR/.mvn/wrapper/MavenWrapperDownloader.java\"\r\n"
				+ "        # For Cygwin, switch paths to Windows format before running javac\r\n"
				+ "        if $cygwin; then\r\n"
				+ "          javaClass=`cygpath --path --windows \"$javaClass\"`\r\n"
				+ "        fi\r\n"
				+ "        if [ -e \"$javaClass\" ]; then\r\n"
				+ "            if [ ! -e \"$BASE_DIR/.mvn/wrapper/MavenWrapperDownloader.class\" ]; then\r\n"
				+ "                if [ \"$MVNW_VERBOSE\" = true ]; then\r\n"
				+ "                  echo \" - Compiling MavenWrapperDownloader.java ...\"\r\n"
				+ "                fi\r\n"
				+ "                # Compiling the Java class\r\n"
				+ "                (\"$JAVA_HOME/bin/javac\" \"$javaClass\")\r\n"
				+ "            fi\r\n"
				+ "            if [ -e \"$BASE_DIR/.mvn/wrapper/MavenWrapperDownloader.class\" ]; then\r\n"
				+ "                # Running the downloader\r\n"
				+ "                if [ \"$MVNW_VERBOSE\" = true ]; then\r\n"
				+ "                  echo \" - Running MavenWrapperDownloader.java ...\"\r\n"
				+ "                fi\r\n"
				+ "                (\"$JAVA_HOME/bin/java\" -cp .mvn/wrapper MavenWrapperDownloader \"$MAVEN_PROJECTBASEDIR\")\r\n"
				+ "            fi\r\n"
				+ "        fi\r\n"
				+ "    fi\r\n"
				+ "fi\r\n"
				+ "##########################################################################################\r\n"
				+ "# End of extension\r\n"
				+ "##########################################################################################\r\n"
				+ "\r\n"
				+ "export MAVEN_PROJECTBASEDIR=${MAVEN_BASEDIR:-\"$BASE_DIR\"}\r\n"
				+ "if [ \"$MVNW_VERBOSE\" = true ]; then\r\n"
				+ "  echo $MAVEN_PROJECTBASEDIR\r\n"
				+ "fi\r\n"
				+ "MAVEN_OPTS=\"$(concat_lines \"$MAVEN_PROJECTBASEDIR/.mvn/jvm.config\") $MAVEN_OPTS\"\r\n"
				+ "\r\n"
				+ "# For Cygwin, switch paths to Windows format before running java\r\n"
				+ "if $cygwin; then\r\n"
				+ "  [ -n \"$M2_HOME\" ] &&\r\n"
				+ "    M2_HOME=`cygpath --path --windows \"$M2_HOME\"`\r\n"
				+ "  [ -n \"$JAVA_HOME\" ] &&\r\n"
				+ "    JAVA_HOME=`cygpath --path --windows \"$JAVA_HOME\"`\r\n"
				+ "  [ -n \"$CLASSPATH\" ] &&\r\n"
				+ "    CLASSPATH=`cygpath --path --windows \"$CLASSPATH\"`\r\n"
				+ "  [ -n \"$MAVEN_PROJECTBASEDIR\" ] &&\r\n"
				+ "    MAVEN_PROJECTBASEDIR=`cygpath --path --windows \"$MAVEN_PROJECTBASEDIR\"`\r\n"
				+ "fi\r\n"
				+ "\r\n"
				+ "# Provide a \"standardized\" way to retrieve the CLI args that will\r\n"
				+ "# work with both Windows and non-Windows executions.\r\n"
				+ "MAVEN_CMD_LINE_ARGS=\"$MAVEN_CONFIG $@\"\r\n"
				+ "export MAVEN_CMD_LINE_ARGS\r\n"
				+ "\r\n"
				+ "WRAPPER_LAUNCHER=org.apache.maven.wrapper.MavenWrapperMain\r\n"
				+ "\r\n"
				+ "exec \"$JAVACMD\" \\\r\n"
				+ "  $MAVEN_OPTS \\\r\n"
				+ "  $MAVEN_DEBUG_OPTS \\\r\n"
				+ "  -classpath \"$MAVEN_PROJECTBASEDIR/.mvn/wrapper/maven-wrapper.jar\" \\\r\n"
				+ "  \"-Dmaven.home=${M2_HOME}\" \\\r\n"
				+ "  \"-Dmaven.multiModuleProjectDirectory=${MAVEN_PROJECTBASEDIR}\" \\\r\n"
				+ "  ${WRAPPER_LAUNCHER} $MAVEN_CONFIG \"$@\"";
		FileWriter fileWriter = new FileWriter(PATH+"/mvnw");
		fileWriter.write(data);
		fileWriter.close();
	}
	public void createHelpMdFile() throws IOException
	{
		String data = "# Getting Started\r\n"
				+ "\r\n"
				+ "### Reference Documentation\r\n"
				+ "For further reference, please consider the following sections:\r\n"
				+ "\r\n"
				+ "* [Official Apache Maven documentation](https://maven.apache.org/guides/index.html)\r\n"
				+ "* [Spring Boot Maven Plugin Reference Guide](https://docs.spring.io/spring-boot/docs/2.7.3/maven-plugin/reference/html/)\r\n"
				+ "* [Create an OCI image](https://docs.spring.io/spring-boot/docs/2.7.3/maven-plugin/reference/html/#build-image)\r\n"
				+ "* [Spring Boot Actuator](https://docs.spring.io/spring-boot/docs/2.7.3/reference/htmlsingle/#actuator)\r\n"
				+ "* [Eureka Discovery Client](https://docs.spring.io/spring-cloud-netflix/docs/current/reference/html/#service-discovery-eureka-clients)\r\n"
				+ "* [Gateway](https://docs.spring.io/spring-cloud-gateway/docs/current/reference/html/)\r\n"
				+ "\r\n"
				+ "### Guides\r\n"
				+ "The following guides illustrate how to use some features concretely:\r\n"
				+ "\r\n"
				+ "* [Building a RESTful Web Service with Spring Boot Actuator](https://spring.io/guides/gs/actuator-service/)\r\n"
				+ "* [Service Registration and Discovery with Eureka and Spring Cloud](https://spring.io/guides/gs/service-registration-and-discovery/)\r\n"
				+ "* [Using Spring Cloud Gateway](https://github.com/spring-cloud-samples/spring-cloud-gateway-sample)";
		FileWriter fileWriter = new FileWriter(PATH+"/HELP.md");
		fileWriter.write(data);
		fileWriter.close();
	}
	public void createProjectFile() throws IOException
	{
		String data = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n"
				+ "<projectDescription>\r\n"
				+ "	<name>APIGateway</name>\r\n"
				+ "	<comment></comment>\r\n"
				+ "	<projects>\r\n"
				+ "	</projects>\r\n"
				+ "	<buildSpec>\r\n"
				+ "		<buildCommand>\r\n"
				+ "			<name>org.eclipse.jdt.core.javabuilder</name>\r\n"
				+ "			<arguments>\r\n"
				+ "			</arguments>\r\n"
				+ "		</buildCommand>\r\n"
				+ "		<buildCommand>\r\n"
				+ "			<name>org.eclipse.m2e.core.maven2Builder</name>\r\n"
				+ "			<arguments>\r\n"
				+ "			</arguments>\r\n"
				+ "		</buildCommand>\r\n"
				+ "		<buildCommand>\r\n"
				+ "			<name>org.springframework.ide.eclipse.boot.validation.springbootbuilder</name>\r\n"
				+ "			<arguments>\r\n"
				+ "			</arguments>\r\n"
				+ "		</buildCommand>\r\n"
				+ "	</buildSpec>\r\n"
				+ "	<natures>\r\n"
				+ "		<nature>org.eclipse.jdt.core.javanature</nature>\r\n"
				+ "		<nature>org.eclipse.m2e.core.maven2Nature</nature>\r\n"
				+ "	</natures>\r\n"
				+ "</projectDescription>";
		FileWriter fileWriter = new FileWriter(PATH+"/.project");
		fileWriter.write(data);
		fileWriter.close();
	}
	public void createGitIgnoreFile() throws IOException
	{
		String data = "HELP.md\r\n"
				+ "target/\r\n"
				+ "!.mvn/wrapper/maven-wrapper.jar\r\n"
				+ "!**/src/main/**/target/\r\n"
				+ "!**/src/test/**/target/\r\n"
				+ "\r\n"
				+ "### STS ###\r\n"
				+ ".apt_generated\r\n"
				+ ".classpath\r\n"
				+ ".factorypath\r\n"
				+ ".project\r\n"
				+ ".settings\r\n"
				+ ".springBeans\r\n"
				+ ".sts4-cache\r\n"
				+ "\r\n"
				+ "### IntelliJ IDEA ###\r\n"
				+ ".idea\r\n"
				+ "*.iws\r\n"
				+ "*.iml\r\n"
				+ "*.ipr\r\n"
				+ "\r\n"
				+ "### NetBeans ###\r\n"
				+ "/nbproject/private/\r\n"
				+ "/nbbuild/\r\n"
				+ "/dist/\r\n"
				+ "/nbdist/\r\n"
				+ "/.nb-gradle/\r\n"
				+ "build/\r\n"
				+ "!**/src/main/**/build/\r\n"
				+ "!**/src/test/**/build/\r\n"
				+ "\r\n"
				+ "### VS Code ###\r\n"
				+ ".vscode/";
		FileWriter fileWriter = new FileWriter(PATH+"/.gitignore");
		fileWriter.write(data);
		fileWriter.close();
	}
	public void createClassPathFile() throws IOException
	{
		String data = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n"
				+ "<classpath>\r\n"
				+ "	<classpathentry kind=\"src\" output=\"target/classes\" path=\"src/main/java\">\r\n"
				+ "		<attributes>\r\n"
				+ "			<attribute name=\"optional\" value=\"true\"/>\r\n"
				+ "			<attribute name=\"maven.pomderived\" value=\"true\"/>\r\n"
				+ "		</attributes>\r\n"
				+ "	</classpathentry>\r\n"
				+ "	<classpathentry excluding=\"**\" kind=\"src\" output=\"target/classes\" path=\"src/main/resources\">\r\n"
				+ "		<attributes>\r\n"
				+ "			<attribute name=\"maven.pomderived\" value=\"true\"/>\r\n"
				+ "		</attributes>\r\n"
				+ "	</classpathentry>\r\n"
				+ "	<classpathentry kind=\"src\" output=\"target/test-classes\" path=\"src/test/java\">\r\n"
				+ "		<attributes>\r\n"
				+ "			<attribute name=\"optional\" value=\"true\"/>\r\n"
				+ "			<attribute name=\"maven.pomderived\" value=\"true\"/>\r\n"
				+ "			<attribute name=\"test\" value=\"true\"/>\r\n"
				+ "		</attributes>\r\n"
				+ "	</classpathentry>\r\n"
				+ "	<classpathentry kind=\"con\" path=\"org.eclipse.jdt.launching.JRE_CONTAINER/org.eclipse.jdt.internal.debug.ui.launcher.StandardVMType/JavaSE-17\">\r\n"
				+ "		<attributes>\r\n"
				+ "			<attribute name=\"maven.pomderived\" value=\"true\"/>\r\n"
				+ "		</attributes>\r\n"
				+ "	</classpathentry>\r\n"
				+ "	<classpathentry kind=\"con\" path=\"org.eclipse.m2e.MAVEN2_CLASSPATH_CONTAINER\">\r\n"
				+ "		<attributes>\r\n"
				+ "			<attribute name=\"maven.pomderived\" value=\"true\"/>\r\n"
				+ "		</attributes>\r\n"
				+ "	</classpathentry>\r\n"
				+ "	<classpathentry kind=\"output\" path=\"target/classes\"/>\r\n"
				+ "</classpath>";
		FileWriter fileWriter = new FileWriter(PATH+"/.classpath");
		fileWriter.write(data);
		fileWriter.close();
	}
	private void createDirectory(String path)
	{
		String[] arr = path.split("/");
		if(arr.length>1)
		{
			String[] strarr = new String[arr.length];
			for(int i=0; i<arr.length; i++)
			{
				if(i==0)
					strarr[i] = arr[i];
				else
					strarr[i] = strarr[i-1] + "/" + arr[i];
				//System.out.println(PATH+"/"+strarr[i]);
				File directory = new File(PATH+"/"+strarr[i]);
				if(!directory.exists())
				{
					directory.mkdir();
				}
			}
		}
		else
		{
			File directory = new File(PATH+"/"+path);
			if(!directory.exists())
			{
				directory.mkdir();
			}
		}
	}
	public void createApiGatewayAppClass() throws IOException
	{
		String path = "src/main/java/com/example/demo";
		createDirectory(path);
		String data = "package com.example.demo;\r\n"
				+ "\r\n"
				+ "import org.springframework.boot.SpringApplication;\r\n"
				+ "import org.springframework.boot.autoconfigure.SpringBootApplication;\r\n"
				+ "import org.springframework.cloud.netflix.eureka.EnableEurekaClient;\r\n"
				+ "\r\n"
				+ "@SpringBootApplication\r\n"
				+ "@EnableEurekaClient\r\n"
				+ "public class ApiGatewayApplication {\r\n"
				+ "\r\n"
				+ "	public static void main(String[] args) {\r\n"
				+ "		SpringApplication.run(ApiGatewayApplication.class, args);\r\n"
				+ "	}\r\n"
				+ "\r\n"
				+ "}";
		FileWriter fileWriter = new FileWriter(PATH+"/"+path+"/ApiGatewayApplication.java");
		fileWriter.write(data);
		fileWriter.close();
	}
	public void corsConfigurationClass() throws IOException
	{
		String path = "src/main/java/com/example/demo";
		createDirectory(path);
		String data = "package com.example.demo;\r\n"
				+ "\r\n"
				+ "import org.springframework.context.annotation.Bean;\r\n"
				+ "import org.springframework.context.annotation.Configuration;\r\n"
				+ "import org.springframework.web.cors.reactive.CorsWebFilter;\r\n"
				+ "import org.springframework.web.cors.reactive.UrlBasedCorsConfigurationSource;\r\n"
				+ "\r\n"
				+ "import java.util.Arrays;\r\n"
				+ "import java.util.Collections;\r\n"
				+ "\r\n"
				+ "@Configuration\r\n"
				+ "public class CorsConfiguration extends org.springframework.web.cors.CorsConfiguration {\r\n"
				+ "\r\n"
				+ "    @Bean\r\n"
				+ "    public CorsWebFilter corsWebFilter() {\r\n"
				+ "\r\n"
				+ "    final CorsConfiguration corsConfig = new CorsConfiguration();\r\n"
				+ "    corsConfig.setAllowedOrigins(Collections.singletonList(\"*\"));\r\n"
				+ "    corsConfig.setMaxAge(3600L);\r\n"
				+ "    corsConfig.setAllowedMethods(Arrays.asList(\"GET\", \"POST\", \"PUT\", \"DELETE\"));\r\n"
				+ "    corsConfig.addAllowedHeader(\"*\");\r\n"
				+ "\r\n"
				+ "    final UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();\r\n"
				+ "    source.registerCorsConfiguration(\"/**\", corsConfig);\r\n"
				+ "\r\n"
				+ "    return new CorsWebFilter(source);\r\n"
				+ "    }\r\n"
				+ "}";
		FileWriter fileWriter = new FileWriter(PATH+"/"+path+"/CorsConfiguration.java");
		fileWriter.write(data);
		fileWriter.close();
	}
	private String getString(String str, int i)
	{
		String res = "\r\n"
				+ "            -   id: "+str.toUpperCase()+"-SERVICE\r\n"
				+ "                predicates:\r\n"
				+ "                - Path=/"+str.toLowerCase()+"/**\r\n"
				+ "                uri: lb://"+str.toUpperCase()+"-SERVICE";
		return res;
	}
	public void createAppProperties(String[] array) throws IOException
	{
		String path = "src/main/resources";
		createDirectory(path);
		String data = "eureka:\r\n"
				+ "    client:\r\n"
				+ "        fetch-registry: true\r\n"
				+ "        register-with-eureka: true\r\n"
				+ "        serviceUrl:\r\n"
				+ "            defaultZone: http://localhost:8761/eureka\r\n"
				+ "    instance:\r\n"
				+ "        hostname: localhost\r\n"
				+ "server:\r\n"
				+ "    port: 9000\r\n"
				+ "    forward-headers-strategy: framework\r\n"
				+ "spring:\r\n"
				+ "    application:\r\n"
				+ "        name: API-GATEWAY\r\n"
				+ "    cloud:\r\n"
				+ "        gateway:\r\n"
				+ "            default-filters:\r\n"
				+ "            - DedupeResponseHeader=Access-Control-Allow-Credentials Access-Control-Allow-Origin\r\n"
				+ "            globalcors:\r\n"
				+ "                corsConfigurations:\r\n"
				+ "                    '[/**]':\r\n"
				+ "                        allowedHeaders: \"*\"\r\n"
				+ "                        allowedMethods: \"*\"\r\n"
				+ "                        allowedOrigins: \"*\"\r\n"
				+ "            routes:"
				+ "\r\n";
		for(int i=0; i<array.length; i++)
		{
			data += getString(array[i], i);
		}
		FileWriter fileWriter = new FileWriter(PATH+"/"+path+"/application.yml");
		fileWriter.write(data);
		fileWriter.close();
	}
	public void createApiGatewayAppTests() throws IOException
	{
		String path = "src/test/java/com/example/demo";
		createDirectory(path);
		String data = "package com.example.demo;\r\n"
				+ "\r\n"
				+ "import org.junit.jupiter.api.Test;\r\n"
				+ "import org.springframework.boot.test.context.SpringBootTest;\r\n"
				+ "\r\n"
				+ "@SpringBootTest\r\n"
				+ "class ApiGatewayApplicationTests {\r\n"
				+ "\r\n"
				+ "	@Test\r\n"
				+ "	void contextLoads() {\r\n"
				+ "	}\r\n"
				+ "\r\n"
				+ "}\r\n"
				+ "";
		FileWriter fileWriter = new FileWriter(PATH+"/"+path+"/ApiGatewayApplicationTests.java");
		fileWriter.write(data);
		fileWriter.close();
	}
	public void createTargetFolder() throws IOException
	{
		String path = "target/classes";
		createDirectory(path);
	}
	public void createmvnfolder()
	{
		String path = ".mvn";
		createDirectory(path);
	}
	public void setting1() throws IOException
	{
		String path = ".settings";
		createDirectory(path);
		String data = "eclipse.preferences.version=1\r\n"
				+ "encoding//src/main/java=UTF-8\r\n"
				+ "encoding//src/main/resources=UTF-8\r\n"
				+ "encoding//src/test/java=UTF-8\r\n"
				+ "encoding/<project>=UTF-8\r\n"
				+ "";
		FileWriter fileWriter = new FileWriter(PATH+"/"+path+"/org.eclipse.core.resources.prefs");
		fileWriter.write(data);
		fileWriter.close();
	}
	public void setting2() throws IOException
	{
		String path = ".settings";
		createDirectory(path);
		String data = "eclipse.preferences.version=1\r\n"
				+ "org.eclipse.jdt.core.compiler.codegen.methodParameters=generate\r\n"
				+ "org.eclipse.jdt.core.compiler.codegen.targetPlatform=17\r\n"
				+ "org.eclipse.jdt.core.compiler.compliance=17\r\n"
				+ "org.eclipse.jdt.core.compiler.problem.enablePreviewFeatures=disabled\r\n"
				+ "org.eclipse.jdt.core.compiler.problem.forbiddenReference=warning\r\n"
				+ "org.eclipse.jdt.core.compiler.problem.reportPreviewFeatures=ignore\r\n"
				+ "org.eclipse.jdt.core.compiler.release=disabled\r\n"
				+ "org.eclipse.jdt.core.compiler.source=17";
		FileWriter fileWriter = new FileWriter(PATH+"/"+path+"/org.eclipse.jdt.core.prefs");
		fileWriter.write(data);
		fileWriter.close();
	}
	public void setting3() throws IOException
	{
		String path = ".settings";
		createDirectory(path);
		String data = "activeProfiles=pom.xml\r\n"
				+ "eclipse.preferences.version=1\r\n"
				+ "resolveWorkspaceProjects=true\r\n"
				+ "version=1\r\n"
				+ "";
		FileWriter fileWriter = new FileWriter(PATH+"/"+path+"/org.eclipse.m2e.core.prefs");
		fileWriter.write(data);
		fileWriter.close();
	}
	public void setting4() throws IOException
	{
		String path = ".settings";
		createDirectory(path);
		String data = "boot.validation.initialized=true\r\n"
				+ "eclipse.preferences.version=1";
		FileWriter fileWriter = new FileWriter(PATH+"/"+path+"/org.springframework.ide.eclipse.prefs");
		fileWriter.write(data);
		fileWriter.close();
	}
}
